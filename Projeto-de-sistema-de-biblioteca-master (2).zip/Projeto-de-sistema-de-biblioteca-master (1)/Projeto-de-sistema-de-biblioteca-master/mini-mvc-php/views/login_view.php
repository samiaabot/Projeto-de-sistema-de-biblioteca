
<?php
$erroLogin = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $senha = (string) ($_POST['senha'] ?? '');

    // login ficticio só pra fingir login
    if (
        hash_equals('admin', $usuario) &&
        hash_equals('scriptoria123', $senha)
    ) {
        session_regenerate_id(true);
        $_SESSION['scriptoria_admin'] = true;

        header('Location: index.php?pagina=admin');
        exit;
    }

    $erroLogin = 'Usuário ou senha incorretos. Tente novamente.';
}

require __DIR__ . '/layouts/header.php';

function escaparLogin($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}
?>

<style>
.login-wrap {
    max-width: 460px;
    margin: 55px auto 75px;
    padding: 32px;
    background: #fffdf8;
    border: 1px solid #e8ddcc;
    border-radius: 18px;
    box-shadow: 0 8px 25px rgba(65, 43, 25, .08);
}

.login-wrap h1 {
    margin-top: 0;
    color: #493526;
}

.login-wrap p {
    color: #78695b;
    line-height: 1.6;
}

.login-wrap label {
    display: block;
    margin: 16px 0 7px;
    color: #493526;
    font-weight: 600;
}

.login-wrap input {
    width: 100%;
    box-sizing: border-box;
    padding: 12px;
    border: 1px solid #d9cbb7;
    border-radius: 8px;
    font: inherit;
}

.login-btn {
    width: 100%;
    margin-top: 22px;
    padding: 13px;
    border: 0;
    border-radius: 8px;
    background: #55765b;
    color: white;
    font: inherit;
    font-weight: 700;
    cursor: pointer;
}

.login-btn:hover {
    background: #405d46;
}

.login-erro {
    margin: 15px 0;
    padding: 12px;
    border-radius: 8px;
    background: #fff0ed;
    color: #9d3022;
}

.login-demo {
    margin-top: 22px;
    padding: 14px;
    border-radius: 9px;
    background: #f3ebe2;
}

.login-wrap a {
    color: #654b2e;
}

@media (max-width: 520px) {
    .login-wrap {
        margin: 25px 12px 45px;
        padding: 22px;
    }
}
</style>

<section class="login-wrap">
    <h1>Área administrativa</h1>

    <p>
     
    </p>

    <?php if ($erroLogin !== ''): ?>
        <div class="login-erro">
            <?= escaparLogin($erroLogin) ?>
        </div>
    <?php endif; ?>

    <?php if (($_GET['msg'] ?? '') === 'saiu'): ?>
        <p>Você saiu da área administrativa com sucesso.</p>
    <?php endif; ?>

    <form method="post" action="index.php?pagina=login">
        <label for="usuario">Usuário</label>
        <input
            id="usuario"
            name="usuario"
            type="text"
            autocomplete="username"
            required
        >

        <label for="senha">Senha</label>
        <input
            id="senha"
            name="senha"
            type="password"
            autocomplete="current-password"
            required
        >

        <button class="login-btn" type="submit">
            Entrar
        </button>
    </form>

    <div class="login-demo">
        <strong>Acesso demonstrativo</strong>
        <p>
            Usuário: <code>admin</code><br>
            Senha: <code>scriptoria123</code>
        </p>
    </div>

    <p>
        <a href="index.php">← Voltar à vitrine</a>
    </p>
</section>

<?php require __DIR__ . '/layouts/footer.php'; ?>
