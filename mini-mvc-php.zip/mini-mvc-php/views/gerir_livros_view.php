
<?php
function scriptoriaAdminEscapar($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

$livrosAdmin = is_array($livros ?? null) ? $livros : [];
$livroEdicao = is_array($livroEdicao ?? null) ? $livroEdicao : [];

$categoriasAdmin = [
    'Acadêmicos',
    'Clássicos brasileiros',
    'Ficção',
    'Não ficção',
    'Infantil'
];

$msg = (string) ($_GET['msg'] ?? '');

$mensagens = [
    'salvo' => 'Livro salvo com sucesso!',
    'excluido' => 'Livro excluído com sucesso.',
    'bloqueado' => 'Não foi possível excluir. O livro pode ter empréstimos registrados.',
    'erro' => 'Não foi possível concluir a operação. Confira os dados e tente novamente.'
];

$editando = !empty($livroEdicao['id']);
?>

<style>
.scriptoria-gestao {
    max-width: 1150px;
    margin: 0 auto;
    padding: 30px 20px 50px;
    color: #493526;
}
.scriptoria-gestao h1,
.scriptoria-gestao h2 {
    color: #493526;
}
.scriptoria-gestao .painel {
    background: #fffdf8;
    border: 1px solid #e8ddcc;
    border-radius: 14px;
    padding: 24px;
    margin: 22px 0;
}
.scriptoria-gestao .formulario {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 16px;
}
.scriptoria-gestao .campo {
    display: flex;
    flex-direction: column;
    gap: 7px;
}
.scriptoria-gestao .campo.largo {
    grid-column: 1 / -1;
}
.scriptoria-gestao input,
.scriptoria-gestao select,
.scriptoria-gestao textarea {
    width: 100%;
    box-sizing: border-box;
    padding: 11px;
    border: 1px solid #dfcbb4;
    border-radius: 8px;
    font: inherit;
    background: #fff;
}
.scriptoria-gestao textarea {
    min-height: 100px;
    resize: vertical;
}
.scriptoria-gestao .botoes {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    margin-top: 16px;
}
.scriptoria-gestao .botao {
    display: inline-block;
    border: 0;
    border-radius: 8px;
    padding: 10px 14px;
    background: #55765e;
    color: white;
    text-decoration: none;
    cursor: pointer;
    font: inherit;
}
.scriptoria-gestao .secundario {
    background: #e9dfd1;
    color: #493526;
}
.scriptoria-gestao .perigo {
    background: #9c3e34;
}
.scriptoria-gestao .aviso {
    background: #edf1e9;
    border-radius: 8px;
    padding: 13px;
}
.scriptoria-gestao .tabela-wrapper {
    overflow-x: auto;
}
.scriptoria-gestao table {
    width: 100%;
    border-collapse: collapse;
    text-align: left;
}
.scriptoria-gestao th,
.scriptoria-gestao td {
    padding: 12px;
    border-bottom: 1px solid #eadcc9;
    vertical-align: top;
}
.scriptoria-gestao th {
    background: #f7efe3;
}
.scriptoria-gestao .acoes {
    display: flex;
    gap: 7px;
    flex-wrap: wrap;
}
.scriptoria-gestao .acoes form {
    margin: 0;
}
@media (max-width: 650px) {
    .scriptoria-gestao .formulario {
        grid-template-columns: 1fr;
    }
    .scriptoria-gestao .campo.largo {
        grid-column: auto;
    }
}
</style>

<main class="scriptoria-gestao">
    <h1>Gerir livros</h1>
    <p>Cadastre livros.</p>

    <?php if (isset($mensagens[$msg])): ?>
        <p class="aviso" role="status">
            <?= scriptoriaAdminEscapar($mensagens[$msg]) ?>
        </p>
    <?php endif; ?>

    <section class="painel">
        <h2><?= $editando ? 'Editar livro' : 'Cadastrar livro' ?></h2>

        <form class="formulario" method="POST" action="index.php?pagina=livros">
            <input type="hidden" name="csrf_token"
                   value="<?= scriptoriaAdminEscapar($csrfToken ?? '') ?>">
            <input type="hidden" name="acao" value="salvar">
            <input type="hidden" name="idLivro"
                   value="<?= scriptoriaAdminEscapar($livroEdicao['id'] ?? '') ?>">

            <div class="campo">
                <label for="titulo">Título *</label>
                <input id="titulo" name="titulo" maxlength="200" required
                       value="<?= scriptoriaAdminEscapar($livroEdicao['titulo'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="autor">Autor *</label>
                <input id="autor" name="autor" maxlength="200" required
                       value="<?= scriptoriaAdminEscapar($livroEdicao['autor'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="categoria">Categoria *</label>
                <select id="categoria" name="categoria" required>
                    <?php foreach ($categoriasAdmin as $categoria): ?>
                        <option value="<?= scriptoriaAdminEscapar($categoria) ?>"
                            <?= ($livroEdicao['categoria'] ?? 'Acadêmicos') === $categoria ? 'selected' : '' ?>>
                            <?= scriptoriaAdminEscapar($categoria) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">
                <label for="anoPublicacao">Ano de publicação</label>
                <input id="anoPublicacao" name="anoPublicacao" type="number"
                       min="1" max="<?= (int) date('Y') ?>"
                       value="<?= scriptoriaAdminEscapar($livroEdicao['anoPublicacao'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="localizacao">Localização física *</label>
                <input id="localizacao" name="localizacao" maxlength="200" required
                       placeholder="Ex.: Estante A, Prateleira 2"
                       value="<?= scriptoriaAdminEscapar($livroEdicao['localizacao'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="status">Disponibilidade</label>
                <select id="status" name="status">
                    <option value="DISPONIVEL"
                        <?= strtoupper((string) ($livroEdicao['status'] ?? 'DISPONIVEL')) === 'DISPONIVEL' ? 'selected' : '' ?>>
                        Disponível
                    </option>
                    <option value="INDISPONIVEL"
                        <?= strtoupper((string) ($livroEdicao['status'] ?? '')) === 'INDISPONIVEL' ? 'selected' : '' ?>>
                        Indisponível
                    </option>
                </select>
            </div>

            <div class="campo largo">
                <label for="imagem">Caminho da capa (opcional)</label>
                <input id="imagem" name="imagem" maxlength="500"
                       placeholder="assets/img/livros/ficcao/capa.jpg"
                       value="<?= scriptoriaAdminEscapar($livroEdicao['imagem'] ?? '') ?>">
    
            </div>

            <div class="campo largo">
                <label for="sinopse">Sinopse</label>
                <textarea id="sinopse" name="sinopse"><?= scriptoriaAdminEscapar($livroEdicao['sinopse'] ?? '') ?></textarea>
            </div>

            <div class="campo largo">
                <div class="botoes">
                    <button class="botao" type="submit">
                        <?= $editando ? 'Salvar alterações' : 'Cadastrar livro' ?>
                    </button>

                    <?php if ($editando): ?>
                        <a class="botao secundario" href="index.php?pagina=livros">
                            Cancelar edição
                        </a>
                    <?php endif; ?>

                    <a class="botao secundario" href="index.php?pagina=admin">
                        Voltar ao painel
                    </a>
                </div>
            </div>
        </form>
    </section>

    <section class="painel">
        <h2>Livros cadastrados (<?= count($livrosAdmin) ?>)</h2>

        <?php if (!$livrosAdmin): ?>
            <p>Nenhum livro cadastrado no banco de dados.</p>
        <?php else: ?>
            <div class="tabela-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Livro</th>
                            <th>Categoria</th>
                            <th>Localização</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($livrosAdmin as $livro): ?>
                        <tr>
                            <td>
                                <strong><?= scriptoriaAdminEscapar($livro['titulo'] ?? '') ?></strong><br>
                                <small><?= scriptoriaAdminEscapar($livro['autor'] ?? '') ?></small>
                            </td>
                            <td><?= scriptoriaAdminEscapar($livro['categoria'] ?? '') ?></td>
                            <td><?= scriptoriaAdminEscapar($livro['localizacao'] ?? '') ?></td>
                            <td><?= scriptoriaAdminEscapar($livro['status'] ?? '') ?></td>
                            <td>
                                <div class="acoes">
                                    <a class="botao"
                                       href="index.php?pagina=livros&acao=editar&id=<?= (int) ($livro['id'] ?? 0) ?>">
                                        Editar
                                    </a>

                                    <form method="POST" action="index.php?pagina=livros"
                                          onsubmit="return confirm('Deseja excluir este livro?');">
                                        <input type="hidden" name="csrf_token"
                                               value="<?= scriptoriaAdminEscapar($csrfToken ?? '') ?>">
                                        <input type="hidden" name="acao" value="excluir">
                                        <input type="hidden" name="idLivro"
                                               value="<?= (int) ($livro['id'] ?? 0) ?>">
                                        <button class="botao perigo" type="submit">
                                            Excluir
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>
