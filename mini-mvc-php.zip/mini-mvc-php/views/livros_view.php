
<?php

$listaLivros = isset($livros) && is_array($livros) ? $livros : [];

$buscaAtual = trim((string) (
    $_GET['busca'] ?? $_GET['pesquisa'] ?? $_GET['termo'] ?? ''
));

$categoriaAtual = trim((string) ($_GET['categoria'] ?? ''));

if (!function_exists('scriptoriaNormalizarView')) {
    function scriptoriaNormalizarView(string $texto): string
    {
        $texto = function_exists('mb_strtolower')
            ? mb_strtolower($texto, 'UTF-8')
            : strtolower($texto);

        if (function_exists('iconv')) {
            $convertido = iconv(
                'UTF-8',
                'ASCII//TRANSLIT//IGNORE',
                $texto
            );

            if ($convertido !== false) {
                $texto = $convertido;
            }
        }

        return trim((string) preg_replace('/[^a-z0-9]+/', ' ', $texto));
    }
}

// procura a capa do livro
if (!function_exists('scriptoriaCapaView')) {
    function scriptoriaCapaView(array $livro): ?string
    {
        $raizProjeto = dirname(__DIR__);
        $pastaLivros = $raizProjeto . '/assets/img/livros';

        $imagem = trim((string) ($livro['imagem'] ?? ''));

        if ($imagem !== '') {
            $imagem = str_replace('\\', '/', $imagem);
            $imagem = ltrim($imagem, '/');

            if (strpos($imagem, 'assets/img/livros/') === 0) {
                $arquivo = $raizProjeto . '/' . $imagem;

                if (is_file($arquivo)) {
                    return $imagem;
                }
            }
        }

        if (!is_dir($pastaLivros)) {
            return null;
        }

        $titulo = scriptoriaNormalizarView(
            (string) ($livro['titulo'] ?? '')
        );

        if ($titulo === '') {
            return null;
        }

        $palavrasTitulo = array_values(array_filter(
            explode(' ', $titulo),
            fn($palavra) => strlen($palavra) > 2
        ));

        $melhorCaminho = null;
        $melhorPontuacao = 0;
        $empate = false;

        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(
                $pastaLivros,
                FilesystemIterator::SKIP_DOTS
            )
        );

        foreach ($it as $arquivoEncontrado) {
            if (!$arquivoEncontrado->isFile()) {
                continue;
            }

            $ext = strtolower($arquivoEncontrado->getExtension());

            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true)) {
                continue;
            }

            $nomeArquivo = scriptoriaNormalizarView(
                pathinfo(
                    $arquivoEncontrado->getFilename(),
                    PATHINFO_FILENAME
                )
            );

            $caminho = substr(
                $arquivoEncontrado->getPathname(),
                strlen($raizProjeto) + 1
            );

            $caminho = str_replace(DIRECTORY_SEPARATOR, '/', $caminho);

            if ($nomeArquivo === $titulo) {
                return $caminho;
            }

            $palavrasArquivo = array_values(array_filter(
                explode(' ', $nomeArquivo),
                fn($palavra) => strlen($palavra) > 2
            ));

            if (!$palavrasArquivo || !$palavrasTitulo) {
                continue;
            }

            $comuns = count(array_intersect(
                $palavrasTitulo,
                $palavrasArquivo
            ));

            $pontuacao = $comuns / count($palavrasTitulo);

            if ($pontuacao > $melhorPontuacao) {
                $melhorPontuacao = $pontuacao;
                $melhorCaminho = $caminho;
                $empate = false;
            } elseif (
                $pontuacao > 0 &&
                abs($pontuacao - $melhorPontuacao) < 0.001
            ) {
                $empate = true;
            }
        }

        if ($melhorPontuacao >= 0.60 && !$empate) {
            return $melhorCaminho;
        }

        return null;
    }
}

//  mosttra as 5 categorias do projeto
$categorias = [
    'Acadêmicos',
    'Clássicos brasileiros',
    'Ficção',
    'Não ficção',
    'Infantil'
];

?>

<style>
    .scriptoria-catalogo {
        max-width: 1450px;
        margin: 0 auto;
        padding: 28px;
        color: #493526;
    }

    .scriptoria-filtros {
        display: grid;
        grid-template-columns: minmax(220px, 1fr) minmax(200px, 325px) auto;
        gap: 12px;
        margin: 24px 0;
    }

    .scriptoria-filtros input,
    .scriptoria-filtros select {
        width: 100%;
        min-width: 0;
        box-sizing: border-box;
        padding: 15px;
        border: 1px solid #dfcbb4;
        border-radius: 11px;
        background: #fff;
        color: #30251d;
        font-size: 16px;
    }

    .scriptoria-botao {
        display: inline-block;
        padding: 15px 22px;
        border: 0;
        border-radius: 11px;
        background: #55765e;
        color: white;
        font-size: 16px;
        text-decoration: none;
        cursor: pointer;
    }

    .scriptoria-botao:hover {
        background: #3f5e48;
    }

    .scriptoria-limpar {
        display: inline-block;
        margin-bottom: 22px;
        color: #42634b;
        text-decoration: none;
    }

    .scriptoria-contagem {
        margin: 20px 0;
        color: #806b59;
    }

    .scriptoria-grade {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));
        gap: 22px;
    }

    .scriptoria-livro {
        display: flex;
        flex-direction: column;
        min-width: 0;
        padding: 18px;
        border: 1px solid #eadcc9;
        border-radius: 16px;
        background: #fffdf9;
        box-shadow: 0 4px 15px rgba(73, 53, 38, 0.06);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .scriptoria-livro:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 22px rgba(73, 53, 38, 0.12);
    }

    .scriptoria-capa-area {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 245px;
        margin-bottom: 15px;
        overflow: hidden;
        border-radius: 10px;
        background: #f7efe3;
    }

    .scriptoria-capa {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: contain;
    }

    .scriptoria-sem-capa {
        padding: 20px;
        color: #806b59;
        text-align: center;
        font-size: 14px;
    }

    .scriptoria-categoria {
        display: inline-block;
        align-self: flex-start;
        margin-bottom: 9px;
        padding: 5px 9px;
        border-radius: 20px;
        background: #edf1e9;
        color: #42634b;
        font-size: 12px;
    }

    .scriptoria-livro h2 {
        margin: 0 0 8px;
        color: #493526;
        font-size: 18px;
        line-height: 1.4;
        overflow-wrap: anywhere;
    }

    .scriptoria-autor {
        margin: 0 0 10px;
        color: #806b59;
        font-size: 14px;
    }

    .scriptoria-sinopse {
        margin: 0 0 14px;
        color: #5e5145;
        font-size: 14px;
        line-height: 1.6;
        overflow-wrap: anywhere;
    }

    .scriptoria-detalhes {
        margin-top: auto;
        padding-top: 12px;
        border-top: 1px solid #eee2d3;
        font-size: 13px;
        line-height: 1.7;
    }

    .scriptoria-status {
        display: inline-block;
        margin-top: 8px;
        padding: 5px 9px;
        border-radius: 7px;
        background: #e7f3e8;
        color: #2e6738;
        font-weight: bold;
    }

    .scriptoria-status.indisponivel {
        background: #f9e8e5;
        color: #9c3e34;
    }

    .scriptoria-vazio {
        padding: 55px 20px;
        border: 1px dashed #dfcbb4;
        border-radius: 16px;
        color: #806b59;
        text-align: center;
    }

    .scriptoria-vazio h2 {
        color: #493526;
    }

    @media (max-width: 760px) {
        .scriptoria-catalogo {
            padding: 16px;
        }

        .scriptoria-filtros {
            grid-template-columns: 1fr;
        }

        .scriptoria-grade {
            grid-template-columns: repeat(auto-fill, minmax(155px, 1fr));
            gap: 12px;
        }

        .scriptoria-livro {
            padding: 12px;
        }

        .scriptoria-capa-area {
            height: 200px;
        }
    }
</style>

<div class="scriptoria-catalogo">

    <form class="scriptoria-filtros" method="GET" action="index.php">
        <input type="hidden" name="pagina" value="catalogo">

        <input
            type="search"
            name="busca"
            value="<?= htmlspecialchars($buscaAtual, ENT_QUOTES, 'UTF-8') ?>"
            placeholder="Buscar por título, autor ou sinopse..."
            aria-label="Buscar livros"
        >

        <select name="categoria" aria-label="Filtrar por categoria">
            <option value="">Todas as categorias</option>

            <?php foreach ($categorias as $categoria): ?>
                <option
                    value="<?= htmlspecialchars($categoria, ENT_QUOTES, 'UTF-8') ?>"
                    <?= scriptoriaNormalizarView($categoriaAtual) === scriptoriaNormalizarView($categoria) ? 'selected' : '' ?>
                >
                    <?= htmlspecialchars($categoria, ENT_QUOTES, 'UTF-8') ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button class="scriptoria-botao" type="submit">Buscar</button>
    </form>

    <a class="scriptoria-limpar" href="index.php?pagina=catalogo">
        Limpar filtros
    </a>

    <p class="scriptoria-contagem">
        <?= count($listaLivros) ?> livro(s) encontrado(s).
    </p>

    <?php if (empty($listaLivros)): ?>

        <section class="scriptoria-vazio">
            <h2>Nenhum livro encontrado</h2>
            <p>Tente outro título ou autor, ou selecione outra categoria.</p>
            <a class="scriptoria-botao" href="index.php?pagina=catalogo">
                Ver todos os livros
            </a>
        </section>

    <?php else: ?>

        <section class="scriptoria-grade" aria-label="Catálogo de livros">

            <?php foreach ($listaLivros as $livro): ?>
                <?php
                $titulo = (string) ($livro['titulo'] ?? 'Título não informado');
                $autor = (string) ($livro['autor'] ?? 'Autor não informado');
                $categoriaLivro = (string) ($livro['categoria'] ?? 'Sem categoria');
                $sinopse = trim((string) ($livro['sinopse'] ?? ''));
                $ano = $livro['anoPublicacao'] ?? null;
                $status = strtoupper(trim((string) ($livro['status'] ?? 'DISPONIVEL')));
                $localizacao = trim((string) ($livro['localizacao'] ?? ''));
                $capa = scriptoriaCapaView($livro);

                $disponivel = in_array(
                    $status,
                    ['DISPONIVEL', 'DISPONÍVEL', 'LIVRE'],
                    true
                );
                ?>

                <article class="scriptoria-livro">

                    <div class="scriptoria-capa-area">
                        <?php if ($capa !== null): ?>
                            <img
                                class="scriptoria-capa"
                                src="<?= htmlspecialchars($capa, ENT_QUOTES, 'UTF-8') ?>"
                                alt="Capa de <?= htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8') ?>"
                                loading="lazy"
                                onerror="this.style.display='none'; this.nextElementSibling.style.display='block';"
                            >
                            <div class="scriptoria-sem-capa" style="display:none">
                                Capa indisponível
                            </div>
                        <?php else: ?>
                            <div class="scriptoria-sem-capa">Capa indisponível</div>
                        <?php endif; ?>
                    </div>

                    <span class="scriptoria-categoria">
                        <?= htmlspecialchars($categoriaLivro, ENT_QUOTES, 'UTF-8') ?>
                    </span>

                    <h2><?= htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8') ?></h2>

                    <p class="scriptoria-autor">
                        <strong>Autor:</strong>
                        <?= htmlspecialchars($autor, ENT_QUOTES, 'UTF-8') ?>
                    </p>

                    <p class="scriptoria-sinopse">
                        <?= $sinopse !== ''
                            ? htmlspecialchars($sinopse, ENT_QUOTES, 'UTF-8')
                            : 'Sinopse não cadastrada.' ?>
                    </p>

                    <div class="scriptoria-detalhes">

                        <?php if ($ano !== null && $ano !== ''): ?>
                            <div>
                                <strong>Ano:</strong>
                                <?= htmlspecialchars((string) $ano, ENT_QUOTES, 'UTF-8') ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($localizacao !== ''): ?>
                            <div>
                                <strong>Localização:</strong>
                                <?= htmlspecialchars($localizacao, ENT_QUOTES, 'UTF-8') ?>
                            </div>
                        <?php endif; ?>

                        <div>
                            <strong>Disponibilidade:</strong><br>
                            <span class="scriptoria-status <?= $disponivel ? '' : 'indisponivel' ?>">
                                <?= $disponivel ? 'Disponível' : 'Indisponível' ?>
                            </span>
                        </div>

                    </div>
                </article>
            <?php endforeach; ?>

        </section>

    <?php endif; ?>

</div>
