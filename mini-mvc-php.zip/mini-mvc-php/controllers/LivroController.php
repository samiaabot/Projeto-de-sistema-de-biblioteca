<?php

require_once __DIR__ . '/../models/LivroModel.php';

class LivroController
{
    private LivroModel $model;

    private array $categorias = [
        'Acadêmicos',
        'Clássicos brasileiros',
        'Ficção',
        'Não ficção',
        'Infantil'
    ];

    public function __construct(PDO $pdo)
    {
        $this->model = new LivroModel($pdo);
    }

    public function tratarRequisicao(): void
    {
        $pagina = $_GET['pagina'] ?? 'catalogo';

        if ($pagina === 'livros') {
            $this->gerirLivros();
            return;
        }

        $busca = trim((string) ($_GET['busca'] ?? ''));
        $categoria = trim((string) ($_GET['categoria'] ?? ''));

        $livros = $this->model->listar();

        $normalizar = static function (string $texto): string {
            $texto = function_exists('mb_strtolower')
                ? mb_strtolower($texto, 'UTF-8')
                : strtolower($texto);

            if (function_exists('iconv')) {
                $resultado = iconv(
                    'UTF-8',
                    'ASCII//TRANSLIT//IGNORE',
                    $texto
                );

                if ($resultado !== false) {
                    $texto = $resultado;
                }
            }

            return trim((string) preg_replace('/[^a-z0-9]+/', ' ', $texto));
        };

        if ($busca !== '') {
            $termo = $normalizar($busca);

            $livros = array_filter(
                $livros,
                function (array $livro) use ($termo, $normalizar): bool {
                    $texto = $normalizar(
                        (string) ($livro['titulo'] ?? '') . ' ' .
                        (string) ($livro['autor'] ?? '') . ' ' .
                        (string) ($livro['categoria'] ?? '') . ' ' .
                        (string) ($livro['sinopse'] ?? '')
                    );

                    return strpos($texto, $termo) !== false;
                }
            );
        }

        if ($categoria !== '') {
            $categoriaNormalizada = $normalizar($categoria);

            $livros = array_filter(
                $livros,
                function (array $livro) use (
                    $categoriaNormalizada,
                    $normalizar
                ): bool {
                    return $normalizar(
                        (string) ($livro['categoria'] ?? '')
                    ) === $categoriaNormalizada;
                }
            );
        }

        $livros = array_values($livros);

        require __DIR__ . '/../views/layouts/header.php';
        require __DIR__ . '/../views/livros_view.php';
        require __DIR__ . '/../views/layouts/footer.php';
    }

    private function gerirLivros(): void
    {
        if (empty($_SESSION['scriptoria_admin'])) {
            header('Location: index.php?pagina=login');
            exit;
        }

        if (empty($_SESSION['scriptoria_csrf'])) {
            $_SESSION['scriptoria_csrf'] = bin2hex(random_bytes(32));
        }

        $csrfToken = $_SESSION['scriptoria_csrf'];
        $mensagem = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = (string) ($_POST['csrf_token'] ?? '');

            if (!hash_equals($csrfToken, $token)) {
                http_response_code(403);
                exit('Formulário inválido. Atualize a página e tente novamente.');
            }

            $acao = (string) ($_POST['acao'] ?? '');

            if ($acao === 'excluir') {
                $id = filter_var(
                    $_POST['idLivro'] ?? null,
                    FILTER_VALIDATE_INT
                );

                if (!$id || $id < 1) {
                    $this->redirecionar('erro');
                }

                try {
                    $excluido = $this->model->excluir($id);
                    $this->redirecionar($excluido ? 'excluido' : 'bloqueado');
                } catch (Throwable $e) {
                    error_log($e->getMessage());
                    $this->redirecionar('erro');
                }
            }

            if ($acao === 'salvar') {
                $idTexto = trim((string) ($_POST['idLivro'] ?? ''));
                $titulo = trim((string) ($_POST['titulo'] ?? ''));
                $autor = trim((string) ($_POST['autor'] ?? ''));
                $categoria = trim((string) ($_POST['categoria'] ?? ''));
                $status = strtoupper(trim((string) ($_POST['status'] ?? 'DISPONIVEL')));
                $localizacao = trim((string) ($_POST['localizacao'] ?? ''));
                $anoTexto = trim((string) ($_POST['anoPublicacao'] ?? ''));
                $sinopse = trim((string) ($_POST['sinopse'] ?? ''));
                $imagem = trim((string) ($_POST['imagem'] ?? ''));

                if (
                    $titulo === '' ||
                    $autor === '' ||
                    $localizacao === '' ||
                    !in_array($categoria, $this->categorias, true) ||
                    !in_array($status, ['DISPONIVEL', 'INDISPONIVEL'], true)
                ) {
                    $this->redirecionar('erro');
                }

                $ano = null;

                if ($anoTexto !== '') {
                    $anoValidado = filter_var(
                        $anoTexto,
                        FILTER_VALIDATE_INT
                    );

                    if (
                        $anoValidado === false ||
                        $anoValidado < 1 ||
                        $anoValidado > (int) date('Y')
                    ) {
                        $this->redirecionar('erro');
                    }

                    $ano = $anoValidado;
                }

                if (
                    $imagem !== '' &&
                    (
                        strpos($imagem, 'assets/img/livros/') !== 0 ||
                        strpos($imagem, '..') !== false
                    )
                ) {
                    $this->redirecionar('erro');
                }

                try {
                    if ($idTexto !== '') {
                        $id = filter_var($idTexto, FILTER_VALIDATE_INT);

                        if (!$id || $id < 1 || !$this->model->buscarPorId($id)) {
                            $this->redirecionar('erro');
                        }

                        $this->model->atualizar(
                            $id,
                            $titulo,
                            $autor,
                            $categoria,
                            $status,
                            $localizacao,
                            $ano,
                            $sinopse,
                            $imagem
                        );
                    } else {
                        $this->model->inserir(
                            $titulo,
                            $autor,
                            $categoria,
                            $status,
                            $localizacao,
                            $ano,
                            $sinopse,
                            $imagem
                        );
                    }

                    $this->redirecionar('salvo');
                } catch (Throwable $e) {
                    error_log('Erro ao salvar livro: ' . $e->getMessage());
                    $this->redirecionar('erro');
                }
            }

            $this->redirecionar('erro');
        }

        $livroEdicao = null;

        if (($_GET['acao'] ?? '') === 'editar') {
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

            if ($id && $id > 0) {
                $livroEdicao = $this->model->buscarPorId($id) ?: null;
            }
        }

        $livros = $this->model->listar();

        require __DIR__ . '/../views/layouts/header.php';
        require __DIR__ . '/../views/gerir_livros_view.php';
        require __DIR__ . '/../views/layouts/footer.php';
    }

    private function redirecionar(string $mensagem): void
    {
        header('Location: index.php?pagina=livros&msg=' . rawurlencode($mensagem));
        exit;
    }
}
