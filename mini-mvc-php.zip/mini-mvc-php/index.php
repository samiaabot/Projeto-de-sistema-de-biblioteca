
<?php
session_start();

require_once __DIR__ . '/config/database.php';

$pagina = $_GET['pagina'] ?? 'catalogo';

if ($pagina === 'login') {
    require __DIR__ . '/views/login_view.php';
    exit;
}

if ($pagina === 'logout') {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    header('Location: index.php?pagina=login&msg=saiu');
    exit;
}

if (in_array($pagina, ['admin', 'livros', 'emprestimos'], true)) {
    if (empty($_SESSION['scriptoria_admin'])) {
        header('Location: index.php?pagina=login');
        exit;
    }
}

if ($pagina === 'admin') {
    require_once __DIR__ . '/controllers/AdminController.php';

    $controller = new AdminController($pdo);
    $controller->index();
    exit;
}

if ($pagina === 'livros') {
    require_once __DIR__ . '/controllers/LivroController.php';

    $controller = new LivroController($pdo);
    $controller->tratarRequisicao();
    exit;
}

if ($pagina === 'emprestimos') {
    http_response_code(501);
    echo 'A área de gerenciamento de empréstimos ainda não foi implementada.';
    exit;
}

require_once __DIR__ . '/controllers/LivroController.php';

$controller = new LivroController($pdo);
$controller->tratarRequisicao();
