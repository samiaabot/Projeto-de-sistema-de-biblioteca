
<?php

class LivroModel
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function listar(string $termo = '', string $categoria = ''): array
    {
        $sql = 'SELECT idLivro AS id, titulo, autor, categoria,
                       status, localizacao, anoPublicacao, sinopse, imagem
                FROM livros
                WHERE 1 = 1';

        $params = [];

        if ($termo !== '') {
            $sql .= ' AND (
                titulo LIKE :titulo
                OR autor LIKE :autor
                OR sinopse LIKE :sinopse
            )';

            $busca = '%' . $termo . '%';
            $params[':titulo'] = $busca;
            $params[':autor'] = $busca;
            $params[':sinopse'] = $busca;
        }

        if ($categoria !== '' && $categoria !== 'Todas as categorias') {
            $sql .= ' AND categoria = :categoria';
            $params[':categoria'] = $categoria;
        }

        $sql .= ' ORDER BY titulo COLLATE NOCASE';

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorFiltro(
        string $termo,
        string $categoria = ''
    ): array {
        return $this->listar($termo, $categoria);
    }

    public function buscarPorId(int $idLivro): array|false
    {
        $stmt = $this->pdo->prepare(
            'SELECT idLivro AS id, titulo, autor, categoria,
                    status, localizacao, anoPublicacao, sinopse, imagem
             FROM livros
             WHERE idLivro = :id'
        );

        $stmt->execute([':id' => $idLivro]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function inserir(
        string $titulo,
        string $autor,
        string $categoria,
        string $status,
        string $localizacao,
        ?int $anoPublicacao = null,
        string $sinopse = '',
        string $imagem = ''
    ): void {
        $sql = 'INSERT INTO livros
                (titulo, autor, categoria, status, localizacao,
                 anoPublicacao, sinopse, imagem)
                VALUES
                (:titulo, :autor, :categoria, :status, :localizacao,
                 :ano, :sinopse, :imagem)';

        $stmt = $this->pdo->prepare($sql);

        $stmt->execute([
            ':titulo' => $titulo,
            ':autor' => $autor,
            ':categoria' => $categoria,
            ':status' => $status,
            ':localizacao' => $localizacao,
            ':ano' => $anoPublicacao,
            ':sinopse' => $sinopse,
            ':imagem' => $imagem
        ]);
    }

    public function atualizar(
        int $idLivro,
        string $titulo,
        string $autor,
        string $categoria,
        string $status,
        string $localizacao,
        ?int $anoPublicacao = null,
        string $sinopse = '',
        string $imagem = ''
    ): void {
        $sql = 'UPDATE livros
                SET titulo = :titulo,
                    autor = :autor,
                    categoria = :categoria,
                    status = :status,
                    localizacao = :localizacao,
                    anoPublicacao = :ano,
                    sinopse = :sinopse,
                    imagem = :imagem
                WHERE idLivro = :id';

        $stmt = $this->pdo->prepare($sql);

        $stmt->execute([
            ':id' => $idLivro,
            ':titulo' => $titulo,
            ':autor' => $autor,
            ':categoria' => $categoria,
            ':status' => $status,
            ':localizacao' => $localizacao,
            ':ano' => $anoPublicacao,
            ':sinopse' => $sinopse,
            ':imagem' => $imagem
        ]);
    }

    public function verificarDisponibilidade(int $idLivro): array|false
    {
        $stmt = $this->pdo->prepare(
            'SELECT status, localizacao, categoria
             FROM livros
             WHERE idLivro = :id'
        );

        $stmt->execute([':id' => $idLivro]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function excluir(int $idLivro): bool
    {
        // Não exclui livros que tenham empréstimos registrados.
        $stmt = $this->pdo->prepare(
            'SELECT COUNT(*) FROM emprestimos WHERE idLivro = :id'
        );

        $stmt->execute([':id' => $idLivro]);

        if ((int) $stmt->fetchColumn() > 0) {
            return false;
        }

        $stmt = $this->pdo->prepare(
            'DELETE FROM livros WHERE idLivro = :id'
        );

        $stmt->execute([':id' => $idLivro]);

        return $stmt->rowCount() > 0;
    }
}
