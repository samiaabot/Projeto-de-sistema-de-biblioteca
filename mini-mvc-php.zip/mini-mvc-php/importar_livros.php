
<?php

require __DIR__ . '/config/database.php';

$livros = [
    [
        'titulo' => 'Algoritmos: Teoria e Prática',
        'autor' => 'Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest e Clifford Stein',
        'categoria' => 'Acadêmicos',
        'ano' => 2009,
        'sinopse' => 'Livro de referência sobre algoritmos, análise de complexidade, ordenação, grafos e técnicas fundamentais da computação.',
        'imagem' => 'assets/img/livros/academicos/Algoritmos Teoria e Pratica.jpg'
    ],
    [
        'titulo' => 'Análise de Circuitos Elétricos',
        'autor' => 'William H. Hayt, Jack E. Kemmerly e Steven M. Durbin',
        'categoria' => 'Acadêmicos',
        'ano' => 2012,
        'sinopse' => 'Apresenta os princípios de análise de circuitos elétricos, com conceitos de tensão, corrente, resistência e métodos de resolução.',
        'imagem' => 'assets/img/livros/academicos/Analise de Circuitos Eletricos.jpg'
    ],
    [
        'titulo' => 'Arquitetura de Computadores',
        'autor' => 'William Stallings',
        'categoria' => 'Acadêmicos',
        'ano' => 2013,
        'sinopse' => 'Explica a organização e o funcionamento dos computadores, incluindo processadores, memória, entrada e saída e arquitetura de sistemas.',
        'imagem' => 'assets/img/livros/academicos/Arquitetura de Computadores.jpg'
    ],
    [
        'titulo' => 'Cálculo com Geometria Analítica',
        'autor' => 'Louis Leithold',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Aborda conceitos de cálculo diferencial e integral associados à geometria analítica, com definições, exemplos e exercícios.',
        'imagem' => 'assets/img/livros/academicos/Calculo com Geometria Analitica.jpg'
    ],
    [
        'titulo' => 'Cálculo — Uma Abordagem Intuitiva e Prática',
        'autor' => 'Autor a confirmar pela edição',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Introdução aos conceitos de cálculo com foco na compreensão intuitiva e na aplicação prática dos conteúdos matemáticos.',
        'imagem' => 'assets/img/livros/academicos/Calculo Uma Abordagem Intuitiva e Pratica.jpg'
    ],
    [
        'titulo' => 'Cálculo, Volume 1',
        'autor' => 'James Stewart',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Estuda funções, limites, derivadas e integrais, com aplicações e exercícios voltados à aprendizagem do cálculo.',
        'imagem' => 'assets/img/livros/academicos/Calculo Volume 1.jpg'
    ],
    [
        'titulo' => 'Cálculo, Volume 2',
        'autor' => 'James Stewart',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Continua o estudo do cálculo, incluindo técnicas de integração, sequências, séries e outros tópicos conforme a edição.',
        'imagem' => 'assets/img/livros/academicos/Calculo Volume 2.jpg'
    ],
    [
        'titulo' => 'Dispositivos Eletrônicos',
        'autor' => 'Thomas L. Floyd',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Apresenta componentes e circuitos eletrônicos, incluindo diodos, transistores e aplicações em sistemas eletrônicos.',
        'imagem' => 'assets/img/livros/academicos/Dispositivos Eletronicos.jpg'
    ],
    [
        'titulo' => 'Energia Solar Fotovoltaica',
        'autor' => 'Autor a confirmar pela edição',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Introduz os fundamentos da conversão fotovoltaica e os componentes, dimensionamento e aplicações de sistemas de energia solar.',
        'imagem' => 'assets/img/livros/academicos/Energia Solar Fotovoltaica.jpg'
    ],
    [
        'titulo' => 'Estruturas de Dados e Seus Algoritmos',
        'autor' => 'J. L. Szwarcfiter e L. Markenzon',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Explora estruturas de dados e algoritmos utilizados para organizar, armazenar, pesquisar e processar informações.',
        'imagem' => 'assets/img/livros/academicos/Estruturas de Dados e Seus Algoritmos.jpg'
    ],
    [
        'titulo' => 'Fundamentos da Energia Eólica',
        'autor' => 'Autor a confirmar pela edição',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Apresenta os princípios de geração eólica, o aproveitamento dos ventos e os componentes de sistemas de conversão de energia.',
        'imagem' => 'assets/img/livros/academicos/Fundamentos da Energia Eolica.jpg'
    ],
    [
        'titulo' => 'Geração de Energia Elétrica',
        'autor' => 'Autor a confirmar pela edição',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Aborda formas de geração de energia elétrica e os princípios de funcionamento de diferentes sistemas de produção.',
        'imagem' => 'assets/img/livros/academicos/Geracao de Energia Eletrica.jpg'
    ],
    [
        'titulo' => 'Projeto de Algoritmos',
        'autor' => 'Nivio Ziviani',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Apresenta técnicas de projeto e análise de algoritmos, com exemplos de problemas clássicos e estratégias de solução.',
        'imagem' => 'assets/img/livros/academicos/Projeto de Algoritmos.jpg'
    ],
    [
        'titulo' => 'Renewable Energy',
        'autor' => 'Autor a confirmar pela edição',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Introdução às fontes renováveis de energia, às tecnologias de conversão e aos desafios da geração sustentável.',
        'imagem' => 'assets/img/livros/academicos/Renewable Energy.jpg'
    ],
    [
        'titulo' => 'Sistemas Digitais',
        'autor' => 'Thomas L. Floyd',
        'categoria' => 'Acadêmicos',
        'ano' => null,
        'sinopse' => 'Explica sistemas digitais, álgebra booleana, portas lógicas, circuitos combinacionais e sequenciais.',
        'imagem' => 'assets/img/livros/academicos/Sistemas Digitais.jpg'
    ],
    [
        'titulo' => 'Sistemas Operacionais Modernos',
        'autor' => 'Andrew S. Tanenbaum e Herbert Bos',
        'categoria' => 'Acadêmicos',
        'ano' => 2015,
        'sinopse' => 'Apresenta conceitos de sistemas operacionais, processos, gerenciamento de memória, sistemas de arquivos e segurança.',
        'imagem' => 'assets/img/livros/academicos/Sistemas Operacionais Modernos.jpg'
    ],
    [
        'titulo' => 'Dom Casmurro',
        'autor' => 'Machado de Assis',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1899,
        'sinopse' => 'Bentinho relembra sua relação com Capitu em uma narrativa marcada por ciúme, memória e dúvidas.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Dom casmurro.jpg'
    ],
    [
        'titulo' => 'A Hora da Estrela',
        'autor' => 'Clarice Lispector',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1977,
        'sinopse' => 'A história de Macabéa, uma jovem nordestina no Rio de Janeiro, aborda invisibilidade social, pobreza e identidade.',
        'imagem' => 'assets/img/livros/classicos brasileiros/A Hora da Estrela.jpg'
    ],
    [
        'titulo' => 'A Moreninha',
        'autor' => 'Joaquim Manuel de Macedo',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1844,
        'sinopse' => 'Romance do século XIX que acompanha encontros amorosos, promessas e lembranças de juventude.',
        'imagem' => 'assets/img/livros/classicos brasileiros/A Moreninha.jpg'
    ],
    [
        'titulo' => 'Auto da Compadecida',
        'autor' => 'Ariano Suassuna',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1955,
        'sinopse' => 'Peça teatral que combina humor popular, crítica social e elementos da cultura nordestina.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Auto da Compadecida.jpg'
    ],
    [
        'titulo' => 'Capitães da Areia',
        'autor' => 'Jorge Amado',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1937,
        'sinopse' => 'Retrata a vida de um grupo de meninos em situação de abandono que vive nas ruas de Salvador.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Capitaes da Areia.jpg'
    ],
    [
        'titulo' => 'Grande Sertão: Veredas',
        'autor' => 'João Guimarães Rosa',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1956,
        'sinopse' => 'Riobaldo narra suas experiências no sertão, refletindo sobre amor, violência, destino e a natureza do bem e do mal.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Grande Sertao Veredas.jpg'
    ],
    [
        'titulo' => 'Iracema',
        'autor' => 'José de Alencar',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1865,
        'sinopse' => 'Romance indianista sobre o encontro entre Iracema e Martim e a formação simbólica das origens do Ceará.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Iracema.jpg'
    ],
    [
        'titulo' => 'Macunaíma',
        'autor' => 'Mário de Andrade',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1928,
        'sinopse' => 'As aventuras de um herói sem nenhum caráter misturam folclore, humor e crítica à identidade nacional.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Macunaima.jpg'
    ],
    [
        'titulo' => 'Memórias de um Sargento de Milícias',
        'autor' => 'Manuel Antônio de Almeida',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1854,
        'sinopse' => 'Acompanha as aventuras de Leonardo em uma representação bem-humorada da sociedade carioca do século XIX.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Memorias de um Sargento de Milicias.jpg'
    ],
    [
        'titulo' => 'Memórias Póstumas de Brás Cubas',
        'autor' => 'Machado de Assis',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1881,
        'sinopse' => 'Um narrador já morto revisita a própria vida com ironia e questiona os valores da sociedade de seu tempo.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Memorias Postumas de Bras Cubas.jpg'
    ],
    [
        'titulo' => 'São Bernardo',
        'autor' => 'Graciliano Ramos',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1934,
        'sinopse' => 'Paulo Honório conta sua ascensão como proprietário rural e revela conflitos relacionados a poder, posse e relações humanas.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Sao Bernardo.jpg'
    ],
    [
        'titulo' => 'O Alquimista',
        'autor' => 'Paulo Coelho',
        'categoria' => 'Ficção',
        'ano' => 1988,
        'sinopse' => 'Santiago parte em uma jornada em busca de um tesouro e encontra reflexões sobre sonhos e escolhas.',
        'imagem' => 'assets/img/livros/classicos brasileiros/O Alquimista.jpg'
    ],
    [
        'titulo' => 'O Cortiço',
        'autor' => 'Aluísio Azevedo',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1890,
        'sinopse' => 'Romance naturalista que retrata a vida coletiva em um cortiço carioca e as relações sociais de seus moradores.',
        'imagem' => 'assets/img/livros/classicos brasileiros/O Cortico.jpg'
    ],
    [
        'titulo' => 'O Guarani',
        'autor' => 'José de Alencar',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1857,
        'sinopse' => 'Romance indianista de aventura centrado em Peri e em sua relação com a família de Cecília.',
        'imagem' => 'assets/img/livros/classicos brasileiros/O Guarani.jpg'
    ],
    [
        'titulo' => 'O Quinze',
        'autor' => 'Rachel de Queiroz',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1930,
        'sinopse' => 'Retrata os efeitos da seca de 1915 no Ceará sobre retirantes, famílias e trabalhadores rurais.',
        'imagem' => 'assets/img/livros/classicos brasileiros/O Quinze.jpg'
    ],
    [
        'titulo' => 'O Tempo e o Vento',
        'autor' => 'Érico Veríssimo',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1949,
        'sinopse' => 'Saga que acompanha gerações de famílias e transformações históricas no Rio Grande do Sul.',
        'imagem' => 'assets/img/livros/classicos brasileiros/O Tempo e o Vento.jpg'
    ],
    [
        'titulo' => 'Os Sertões',
        'autor' => 'Euclides da Cunha',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1902,
        'sinopse' => 'Obra que examina o sertão, seus habitantes e a Guerra de Canudos sob perspectivas histórica e social.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Os Sertoes.jpg'
    ],
    [
        'titulo' => 'Triste Fim de Policarpo Quaresma',
        'autor' => 'Lima Barreto',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1915,
        'sinopse' => 'A trajetória de um nacionalista idealista expõe contradições políticas e sociais do Brasil.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Triste Fim de Policarpo Quaresma.jpg'
    ],
    [
        'titulo' => 'Duna',
        'autor' => 'Frank Herbert',
        'categoria' => 'Ficção',
        'ano' => 1965,
        'sinopse' => 'Paul Atreides envolve-se em disputas políticas, religiosas e ecológicas no planeta desértico Arrakis.',
        'imagem' => 'assets/img/livros/ficção/DUNA.jpg'
    ],
    [
        'titulo' => 'Encontro com Rama',
        'autor' => 'Arthur C. Clarke',
        'categoria' => 'Ficção',
        'ano' => 1973,
        'sinopse' => 'Uma equipe espacial investiga um misterioso objeto cilíndrico que entra no Sistema Solar.',
        'imagem' => 'assets/img/livros/ficção/Encontro com Rama.jpg'
    ],
    [
        'titulo' => 'O Guia do Mochileiro das Galáxias',
        'autor' => 'Douglas Adams',
        'categoria' => 'Ficção',
        'ano' => 1979,
        'sinopse' => 'Arthur Dent embarca numa jornada espacial absurda e bem-humorada após a destruição da Terra.',
        'imagem' => 'assets/img/livros/ficção/O Guia do Mochileiro das Galaxias.jpg'
    ],
    [
        'titulo' => 'Perdido em Marte',
        'autor' => 'Andy Weir',
        'categoria' => 'Ficção',
        'ano' => 2011,
        'sinopse' => 'Um astronauta tenta sobreviver sozinho em Marte usando ciência, improvisação e criatividade.',
        'imagem' => 'assets/img/livros/ficção/Perdido em Marte.jpg'
    ],
    [
        'titulo' => 'O Pequeno Príncipe',
        'autor' => 'Antoine de Saint-Exupéry',
        'categoria' => 'Infantil',
        'ano' => 1943,
        'sinopse' => 'Um piloto encontra um pequeno viajante de outro planeta, que compartilha reflexões sobre amizade e responsabilidade.',
        'imagem' => 'assets/img/livros/infantil/O Pequeno Principe.jpg'
    ],
    [
        'titulo' => 'Ou Isto ou Aquilo',
        'autor' => 'Cecília Meireles',
        'categoria' => 'Infantil',
        'ano' => 1964,
        'sinopse' => 'Coletânea de poemas infantis que explora sons, escolhas, imaginação e situações do cotidiano.',
        'imagem' => 'assets/img/livros/infantil/Ou Isto ou Aquilo.jpg'
    ],
    [
        'titulo' => 'Quarto de Despejo',
        'autor' => 'Carolina Maria de Jesus',
        'categoria' => 'Não ficção',
        'ano' => 1960,
        'sinopse' => 'Diário que registra o cotidiano, a fome e a desigualdade vividos pela autora na favela do Canindé, em São Paulo.',
        'imagem' => 'assets/img/livros/não ficção/Quarto de Despejo.jpg'
    ],
    [
        'titulo' => 'Vidas Secas',
        'autor' => 'Graciliano Ramos',
        'categoria' => 'Clássicos brasileiros',
        'ano' => 1938,
        'sinopse' => 'Romance que retrata a luta de uma família de retirantes contra a seca, a pobreza e a opressão no sertão.',
        'imagem' => 'assets/img/livros/classicos brasileiros/Vidas Secas.jpg'
    ],
    [
        'titulo' => 'Sapiens: Uma Breve História da Humanidade',
        'autor' => 'Yuval Noah Harari',
        'categoria' => 'Não ficção',
        'ano' => 2011,
        'sinopse' => 'Uma interpretação ampla da história humana, das primeiras sociedades às transformações das civilizações modernas.',
        'imagem' => 'assets/img/livros/não ficção/Sapiens.jpg'
    ],
    [
        'titulo' => 'O Mundo Assombrado pelos Demônios',
        'autor' => 'Carl Sagan',
        'categoria' => 'Não ficção',
        'ano' => 1995,
        'sinopse' => 'Defende o pensamento científico e o ceticismo diante de alegações que não possuem evidências confiáveis.',
        'imagem' => 'assets/img/livros/não ficção/O Mundo Assombrado pelos Demonios.jpg'
    ],
    [
        'titulo' => 'A Incrível Viagem de Shackleton',
        'autor' => 'Alfred Lansing',
        'categoria' => 'Não ficção',
        'ano' => 1959,
        'sinopse' => 'Relato da expedição de Ernest Shackleton à Antártida e da luta de sua tripulação pela sobrevivência.',
        'imagem' => 'assets/img/livros/não ficção/A Incrivel Viagem de Shackleton.jpg'
    ],
];

function scriptoriaNormalizar(string $texto): string
{
    $texto = mb_strtolower($texto, 'UTF-8');

    if (function_exists('iconv')) {
        $semAcentos = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $texto);
        if ($semAcentos !== false) {
            $texto = $semAcentos;
        }
    }

    $texto = preg_replace('/\.[a-z0-9]{2,5}$/i', '', $texto);

    return trim(preg_replace('/[^a-z0-9]+/', ' ', $texto));
}

function scriptoriaPalavras(string $texto): array
{
    $ignorar = [
        'de', 'da', 'do', 'das', 'dos', 'e', 'a', 'o', 'as',
        'os', 'uma', 'um', 'para', 'por', 'com', 'em', 'volume'
    ];

    return array_values(array_filter(
        explode(' ', scriptoriaNormalizar($texto)),
        fn($p) => strlen($p) > 2 && !in_array($p, $ignorar, true)
    ));
}

function scriptoriaEncontrarCapa(string $titulo, string $categoria): ?string
{
    $raiz = __DIR__ . '/assets/img/livros';

    if (!is_dir($raiz)) {
        return null;
    }

    $pastas = [
        'academicos' => 'Acadêmicos',
        'classicos brasileiros' => 'Clássicos brasileiros',
        'ficção' => 'Ficção',
        'infantil' => 'Infantil',
        'não ficção' => 'Não ficção',
    ];

    $categoriaNormalizada = scriptoriaNormalizar($categoria);
    $pastaAlvo = null;

    foreach ($pastas as $pasta => $nomeCategoria) {
        if (scriptoriaNormalizar($nomeCategoria) === $categoriaNormalizada) {
            $pastaAlvo = $pasta;
            break;
        }
    }

    $arquivos = [];

    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($raiz, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($it as $arquivo) {
        if (
            !$arquivo->isFile()
            || !in_array(
                strtolower($arquivo->getExtension()),
                ['jpg', 'jpeg', 'png', 'webp', 'gif'],
                true
            )
        ) {
            continue;
        }

        $relativo = str_replace(
            DIRECTORY_SEPARATOR,
            '/',
            substr($arquivo->getPathname(), strlen(__DIR__) + 1)
        );

        if (
            $pastaAlvo !== null
            && strpos(
                scriptoriaNormalizar($relativo),
                scriptoriaNormalizar('assets/img/livros/' . $pastaAlvo)
            ) !== 0
        ) {
            continue;
        }

        $base = pathinfo($arquivo->getFilename(), PATHINFO_FILENAME);
        $a = scriptoriaPalavras($titulo);
        $b = scriptoriaPalavras($base);

        if (!$a || !$b) {
            continue;
        }

        $score = count(array_intersect($a, $b)) / count($a);

        if (scriptoriaNormalizar($titulo) === scriptoriaNormalizar($base)) {
            $score = 1;
        }

        $arquivos[] = [
            'score' => $score,
            'path' => $relativo
        ];
    }

    usort($arquivos, fn($x, $y) => $y['score'] <=> $x['score']);

    if (!$arquivos || $arquivos[0]['score'] < 0.60) {
        return null;
    }

    if (
        isset($arquivos[1])
        && abs($arquivos[0]['score'] - $arquivos[1]['score']) < 0.001
    ) {
        return null;
    }

    return $arquivos[0]['path'];
}

$inseridos = 0;
$atualizados = 0;
$errosImagem = 0;
$semCapa = [];

try {
    $colunas = $pdo->query('PRAGMA table_info(livros)')->fetchAll(PDO::FETCH_ASSOC);
    $nomesColunas = array_column($colunas, 'name');

    foreach (['anoPublicacao', 'sinopse', 'imagem'] as $necessaria) {
        if (!in_array($necessaria, $nomesColunas, true)) {
            throw new RuntimeException(
                'A coluna ' . $necessaria .
                ' não existe na tabela livros. Confira config/database.php.'
            );
        }
    }

    $buscar = $pdo->prepare(
        'SELECT idLivro FROM livros
         WHERE LOWER(titulo) = LOWER(:titulo) LIMIT 1'
    );

    $inserir = $pdo->prepare(
        'INSERT INTO livros
        (titulo, autor, categoria, status, localizacao,
         anoPublicacao, sinopse, imagem)
        VALUES
        (:titulo, :autor, :categoria, :status, :localizacao,
         :ano, :sinopse, :imagem)'
    );

    $atualizar = $pdo->prepare(
        'UPDATE livros
         SET autor = :autor,
             categoria = :categoria,
             anoPublicacao = :ano,
             sinopse = :sinopse,
             imagem = :imagem
         WHERE idLivro = :id'
    );

    $pdo->beginTransaction();

    foreach ($livros as $livro) {
        $categoria = $livro['categoria'];
        $capaReal = scriptoriaEncontrarCapa(
            $livro['titulo'],
            $categoria
        );

        if ($capaReal === null) {
            $errosImagem++;
            $semCapa[] = $livro['titulo'];
        }

        $imagem = $capaReal ?? '';

        $buscar->execute([':titulo' => $livro['titulo']]);
        $idExistente = $buscar->fetchColumn();

        if ($idExistente !== false) {
            $dadosAtualizacao = [
                ':autor' => $livro['autor'],
                ':categoria' => $categoria,
                ':ano' => $livro['ano'],
                ':sinopse' => $livro['sinopse'],
                ':imagem' => $imagem,
                ':id' => $idExistente,
            ];

            // Se não encontrou capa, mantém a imagem anterior, se existir.
            if ($imagem === '') {
                $stmtAntigo = $pdo->prepare(
                    'SELECT imagem FROM livros WHERE idLivro = ?'
                );
                $stmtAntigo->execute([$idExistente]);
                $imagemAntiga = $stmtAntigo->fetchColumn();

                $dadosAtualizacao[':imagem'] = $imagemAntiga ?: '';
            }

            $atualizar->execute($dadosAtualizacao);
            $atualizados++;
            continue;
        }

        $inserir->execute([
            ':titulo' => $livro['titulo'],
            ':autor' => $livro['autor'],
            ':categoria' => $categoria,
            ':status' => 'DISPONIVEL',
            ':localizacao' => 'A definir',
            ':ano' => $livro['ano'],
            ':sinopse' => $livro['sinopse'],
            ':imagem' => $imagem,
        ]);

        $inseridos++;
    }

    $pdo->commit();

    echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<title>Importação Scriptoria</title>';
    echo '<style>
        body{font-family:Arial,sans-serif;max-width:850px;margin:40px auto;padding:20px;line-height:1.6;color:#493526}
        h1{color:#315b45}
        .resultado{padding:18px;border:1px solid #ddd;border-radius:8px}
        .aviso{background:#fff4d6;padding:12px;border-radius:6px}
        a{color:#315b45}
    </style></head><body>';

    echo '<h1>Acervo Scriptoria atualizado!</h1>';
    echo '<div class="resultado">';
    echo '<p><strong>Livros novos inseridos:</strong> ' . $inseridos . '</p>';
    echo '<p><strong>Livros existentes atualizados:</strong> ' . $atualizados . '</p>';
    echo '<p><strong>Capas que precisam de conferência:</strong> ' . $errosImagem . '</p>';
    echo '</div>';

    if ($semCapa) {
        echo '<div class="aviso">';
        echo '<strong>Não foi possível associar automaticamente uma capa a estes títulos:</strong><ul>';

        foreach (array_unique($semCapa) as $tituloSemCapa) {
            echo '<li>' . htmlspecialchars(
                $tituloSemCapa,
                ENT_QUOTES,
                'UTF-8'
            ) . '</li>';
        }

        echo '</ul></div>';
    }

    echo '<p><a href="index.php">Abrir catálogo</a></p>';
    echo '<p><strong>Segurança:</strong> depois de confirmar o resultado, exclua este arquivo importador do servidor local.</p>';
    echo '</body></html>';

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code(500);

    echo '<h1>Não foi possível importar o acervo</h1>';
    echo '<p>' . htmlspecialchars(
        $e->getMessage(),
        ENT_QUOTES,
        'UTF-8'
    ) . '</p>';
}

