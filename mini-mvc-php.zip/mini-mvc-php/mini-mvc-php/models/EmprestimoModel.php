<?php

class EmprestimoModel
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    //busca os emprestimos ativos com dados do leitor e livro
    public function listarAtivos(): array
    {
        try {
            $sql = "SELECT e.*, l.titulo AS tituloLivro, u.nome AS nomeUsuario 
                    FROM emprestimos e
                    LEFT JOIN livros l ON e.idLivro = l.idLivro
                    LEFT JOIN usuarios u ON e.idUsuario = u.idUsuario
                    WHERE e.status = 'EM_ANDAMENTO' OR e.status IS NULL OR e.status = ''
                    ORDER BY e.idEmprestimo DESC";
            
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            return [];
        }
    }

    //registra novo emprestimo no banco
    public function criar(int $idUsuario, int $idLivro, string $dataEmprestimo = '', string $dataDevolucao = ''): bool
    {
        try {
            if (empty($dataEmprestimo)) {
                $dataEmprestimo = date('Y-m-d');
            }
            if (empty($dataDevolucao)) {
                $dataDevolucao = date('Y-m-d', strtotime('+14 days'));
            }

            $sql = "INSERT INTO emprestimos (idUsuario, idLivro, dataEmprestimo, dataDevolucao, status) 
                    VALUES (:idUsuario, :idLivro, :dataEmprestimo, :dataDevolucao, 'EM_ANDAMENTO')";
            
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([
                ':idUsuario' => $idUsuario,
                ':idLivro' => $idLivro,
                ':dataEmprestimo' => $dataEmprestimo,
                ':dataDevolucao' => $dataDevolucao
            ]);
        } catch (Throwable $e) {
            return false;
        }
    }

    //marca o emprestimo como devolvido
    public function devolver(int $idEmprestimo): bool
    {
        try {
            $sql = "UPDATE emprestimos SET status = 'DEVOLVIDO', dataDevolucao = :dataDevolucao WHERE idEmprestimo = :id";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([
                ':dataDevolucao' => date('Y-m-d'),
                ':id' => $idEmprestimo
            ]);
        } catch (Throwable $e) {
            return false;
        }
    }
}