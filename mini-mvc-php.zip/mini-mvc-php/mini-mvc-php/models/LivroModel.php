<?php

class LivroModel
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    //lista livros aplicando busca e filtro
    public function listar(string $busca = '', string $categoria = ''): array
    {
        $sql = 'SELECT * FROM livros WHERE 1=1';
        $params = [];

        if ($busca !== '') {
            $sql .= ' AND (titulo LIKE :busca OR autor LIKE :busca OR categoria LIKE :busca)';
            $params[':busca'] = '%' . $busca . '%';
        }

        if ($categoria !== '') {
            $sql .= ' AND LOWER(categoria) LIKE LOWER(:categoria)';
            $params[':categoria'] = '%' . trim($categoria) . '%';
        }

        $sql .= ' ORDER BY titulo ASC';

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    //atalho pro metodo listar
    public function buscarPorFiltro(
        string $termo,
        string $categoria = ''
    ): array {
        return $this->listar($termo, $categoria);
    }

    //busca livro por id
    public function buscarPorId(int $idLivro): array|false
    {
        $stmt = $this->pdo->prepare(
            'SELECT idLivro AS id, titulo, autor, categoria,
                    status, localizacao, anoPublicacao, sinopse, imagem
             FROM livros
             WHERE idLivro = :id'
        );

        $stmt->execute([':id' => $idLivro]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    //insere novo livro
    public function inserir(
        string $titulo,
        string $autor,
        string $categoria,
        string $status,
        string $localizacao,
        ?int $anoPublicacao = null,
        string $sinopse = '',
        string $imagem = ''
    ): void {
        $sql = 'INSERT INTO livros
                (titulo, autor, categoria, status, localizacao,
                 anoPublicacao, sinopse, imagem)
                VALUES
                (:titulo, :autor, :categoria, :status, :localizacao,
                 :ano, :sinopse, :imagem)';

        $stmt = $this->pdo->prepare($sql);

        $stmt->execute([
            ':titulo' => $titulo,
            ':autor' => $autor,
            ':categoria' => $categoria,
            ':status' => $status,
            ':localizacao' => $localizacao,
            ':ano' => $anoPublicacao,
            ':sinopse' => $sinopse,
            ':imagem' => $imagem
        ]);
    }

    //atualiza livro existente
    public function atualizar(
        int $idLivro,
        string $titulo,
        string $autor,
        string $categoria,
        string $status,
        string $localizacao,
        ?int $anoPublicacao = null,
        string $sinopse = '',
        string $imagem = ''
    ): void {
        $sql = 'UPDATE livros
                SET titulo = :titulo,
                    autor = :autor,
                    categoria = :categoria,
                    status = :status,
                    localizacao = :localizacao,
                    anoPublicacao = :ano,
                    sinopse = :sinopse,
                    imagem = :imagem
                WHERE idLivro = :id';

        $stmt = $this->pdo->prepare($sql);

        $stmt->execute([
            ':id' => $idLivro,
            ':titulo' => $titulo,
            ':autor' => $autor,
            ':categoria' => $categoria,
            ':status' => $status,
            ':localizacao' => $localizacao,
            ':ano' => $anoPublicacao,
            ':sinopse' => $sinopse,
            ':imagem' => $imagem
        ]);
    }

    //retorna dados de disponibilidade do livro
    public function verificarDisponibilidade(int $idLivro): array|false
    {
        $stmt = $this->pdo->prepare(
            'SELECT status, localizacao, categoria
             FROM livros
             WHERE idLivro = :id'
        );

        $stmt->execute([':id' => $idLivro]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    //deleta livro se nao houver emprestimos
    public function excluir(int $idLivro): bool
    {
        $stmt = $this->pdo->prepare(
            'SELECT COUNT(*) FROM emprestimos WHERE idLivro = :id'
        );

        $stmt->execute([':id' => $idLivro]);

        if ((int) $stmt->fetchColumn() > 0) {
            return false;
        }

        $stmt = $this->pdo->prepare(
            'DELETE FROM livros WHERE idLivro = :id'
        );

        $stmt->execute([':id' => $idLivro]);

        return $stmt->rowCount() > 0;
    }

    //busca livros mais emprestados
    public function listarPopulares(int $limite = 8): array
    {
        $sql = 'SELECT l.*, COUNT(e.idEmprestimo) AS totalEmprestimos
                FROM livros l
                LEFT JOIN emprestimos e ON l.idLivro = e.idLivro
                GROUP BY l.idLivro
                ORDER BY totalEmprestimos DESC, l.titulo ASC
                LIMIT :limite';

        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}