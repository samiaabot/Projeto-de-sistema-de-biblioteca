<?php

class UsuarioModel
{
    private PDO $pdo;

    //inicia a conexao com o banco
    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    //lista todos os usuarios
    public function listar(): array
    {
        $sql = 'SELECT idUsuario AS id, nome, email, telefone FROM usuarios ORDER BY nome';
        return $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    //busca um usuario pelo id
    public function buscarPorId(int $idUsuario): array|false
    {
        $stmt = $this->pdo->prepare('SELECT idUsuario AS id, nome, email, telefone FROM usuarios WHERE idUsuario = :id');
        $stmt->execute([':id' => $idUsuario]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    //insere novo usuario
    public function inserir(string $nome, string $email, string $telefone): void
    {
        $sql = 'INSERT INTO usuarios (nome, email, telefone) VALUES (:nome, :email, :telefone)';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            ':nome'     => $nome,
            ':email'    => $email,
            ':telefone' => $telefone
        ]);
    }

    //atualiza dados do usuario
    public function atualizar(int $idUsuario, string $nome, string $email, string $telefone): void
    {
        $sql = 'UPDATE usuarios SET nome = :nome, email = :email, telefone = :telefone WHERE idUsuario = :id';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            ':id'       => $idUsuario,
            ':nome'     => $nome,
            ':email'    => $email,
            ':telefone' => $telefone
        ]);
    }

    //exclui usuario se nao tiver emprestimo
    public function excluir(int $idUsuario): bool
    {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM emprestimos WHERE idUsuario = :id');
        $stmt->execute([':id' => $idUsuario]);

        if ((int) $stmt->fetchColumn() > 0) {
            return false;
        }

        $stmt = $this->pdo->prepare('DELETE FROM usuarios WHERE idUsuario = :id');
        $stmt->execute([':id' => $idUsuario]);

        return $stmt->rowCount() > 0;
    }
}