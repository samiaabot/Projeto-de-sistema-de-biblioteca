<?php

class AdminModel
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    //conta o total de livros
    public function contarLivros(): int
    {
        $sql = 'SELECT COUNT(*) FROM livros';

        return (int) $this->pdo->query($sql)->fetchColumn();
    }

    //conta livros disponiveis
    public function contarLivrosDisponiveis(): int
    {
        $sql = "SELECT COUNT(*) FROM livros
                WHERE status = 'DISPONIVEL'";

        return (int) $this->pdo->query($sql)->fetchColumn();
    }

    //conta empréstimos ativos
    public function contarEmprestimosAtivos(): int
    {
        $sql = "SELECT COUNT(*) FROM emprestimos
                WHERE status = 'ATIVO' OR status = 'EM_ANDAMENTO'";

        return (int) $this->pdo->query($sql)->fetchColumn();
    }

    //conta total de usuários
    public function contarUsuarios(): int
    {
        $sql = 'SELECT COUNT(*) FROM usuarios';

        return (int) $this->pdo->query($sql)->fetchColumn();
    }
}
