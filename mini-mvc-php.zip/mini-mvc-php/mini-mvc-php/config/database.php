<?php
/**
 * SCRIPTORIA - CONEXAO COM O BANCO DE DADOS
 * Banco SQLite utilizado pelo projeto PHP no XAMPP.
 */

$pastaDados = __DIR__ . '/../data';

if (!is_dir($pastaDados)) {
    mkdir($pastaDados, 0777, true);
}

$caminhoSqlite = $pastaDados . '/banco.sqlite';
$dsn = 'sqlite:' . $caminhoSqlite;

try {
    $pdo = new PDO($dsn);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON;');
} catch (PDOException $e) {
    exit('Nao foi possivel conectar ao banco de dados.');
}

/*
 * CRIACAO DAS TABELAS
 * 
 */
$pdo->exec(
    'CREATE TABLE IF NOT EXISTS usuarios (
        idUsuario INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT NOT NULL,
        telefone TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS livros (
        idLivro INTEGER PRIMARY KEY AUTOINCREMENT,
        titulo TEXT NOT NULL,
        autor TEXT NOT NULL,
        categoria TEXT NOT NULL,
        status TEXT DEFAULT "DISPONIVEL",
        localizacao TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS emprestimos (
        idEmprestimo INTEGER PRIMARY KEY AUTOINCREMENT,
        idUsuario INTEGER NOT NULL,
        idLivro INTEGER NOT NULL,
        dataEmprestimo TEXT NOT NULL,
        dataDevolucao TEXT NOT NULL,
        dataDevolucaoReal TEXT,
        status TEXT DEFAULT "ATIVO",
        FOREIGN KEY (idUsuario) REFERENCES usuarios(idUsuario),
        FOREIGN KEY (idLivro) REFERENCES livros(idLivro)
    );'
);

$colunasExistentes = $pdo
    ->query('PRAGMA table_info(livros)')
    ->fetchAll(PDO::FETCH_COLUMN, 1);

$novasColunas = [
    'anoPublicacao' => 'INTEGER',
    'sinopse'       => 'TEXT',
    'imagem'        => 'TEXT'
];

foreach ($novasColunas as $coluna => $tipo) {
    if (!in_array($coluna, $colunasExistentes, true)) {
        $pdo->exec(
            "ALTER TABLE livros ADD COLUMN {$coluna} {$tipo}"
        );
    }
}