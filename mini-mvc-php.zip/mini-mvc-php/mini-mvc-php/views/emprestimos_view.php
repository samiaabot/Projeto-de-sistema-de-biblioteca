<?php
//define variaveis padrao de emprestimo e data
$mensagemSucesso = $mensagemSucesso ?? '';
$mensagemErro = $mensagemErro ?? '';
$usuariosLista = $usuariosLista ?? [];
$livrosLista = $livrosLista ?? [];
$emprestimosAtivos = $emprestimosAtivos ?? [];

$hoje = date('Y-m-d');
$dataDevPadrao = date('Y-m-d', strtotime('+14 days'));
?>

<style>
.emprestimos-container {
    max-width: 1100px;
    margin: 30px auto;
    padding: 0 20px;
}

.page-title {
    font-size: 1.8rem;
    font-weight: 700;
    margin: 0 0 4px 0;
    color: #1a1a1a;
}

.page-subtitle {
    font-size: 0.9rem;
    color: #666;
    margin: 0 0 25px 0;
}

.tabs-container {
    display: flex;
    border-bottom: 1px solid #ccc;
    margin-bottom: 25px;
}

.tab-btn {
    padding: 10px 30px;
    font-size: 0.9rem;
    font-weight: 600;
    border: none;
    background: #e8e8e8;
    color: #333;
    cursor: pointer;
}

.tab-btn.active {
    background: #d4d4d4;
    color: #000;
}

.form-summary-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
    margin-bottom: 35px;
}

.card-box {
    border: 1px solid #dcdcdc;
    border-radius: 8px;
    padding: 20px;
    background: #ffffff;
}

.card-box.gray-bg {
    background: #efefef;
    border-color: #e0e0e0;
}

.card-box h3 {
    font-size: 1.05rem;
    font-weight: 700;
    margin: 0 0 15px 0;
    color: #1a1a1a;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    font-size: 0.85rem;
    font-weight: 700;
    margin-bottom: 6px;
    color: #1a1a1a;
}

.input-search-wrapper select,
.input-search-wrapper input[type="date"] {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid #ccc;
    border-radius: 20px;
    font-size: 0.88rem;
    outline: none;
    background: #fff;
    color: #1a1a1a;
}

.dates-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.summary-item {
    border-bottom: 1px solid #dbdbdb;
    padding-bottom: 12px;
    margin-bottom: 12px;
}

.summary-item:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.summary-item label {
    display: block;
    font-size: 0.85rem;
    font-weight: 700;
    color: #1a1a1a;
    margin-bottom: 2px;
}

.summary-item div {
    font-size: 0.82rem;
    color: #555;
}

.btn-confirmar-emprestimo {
    width: 100%;
    padding: 10px;
    background: #1a1a1a;
    color: #fff;
    border: none;
    border-radius: 6px;
    font-weight: 600;
    font-size: 0.9rem;
    cursor: pointer;
    margin-top: 15px;
}

.table-section h3 {
    font-size: 1.1rem;
    font-weight: 700;
    margin: 0 0 15px 0;
}

.table-wrapper {
    border: 1px solid #dcdcdc;
    border-radius: 8px;
    overflow: hidden;
}

.custom-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
}

.custom-table th {
    background: #e8e8e8;
    text-align: left;
    padding: 10px 14px;
    font-weight: 700;
    color: #1a1a1a;
    border-bottom: 1px solid #dcdcdc;
}

.custom-table td {
    padding: 12px 14px;
    border-bottom: 1px solid #eee;
    vertical-align: middle;
}

.custom-table tr:last-child td {
    border-bottom: none;
}

.status-badge {
    display: inline-block;
    background: #e0e0e0;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 0.78rem;
    font-weight: 500;
    color: #333;
}

.alert-msg {
    padding: 10px 15px;
    border-radius: 6px;
    margin-bottom: 20px;
    font-size: 0.85rem;
}

.alert-msg.success { background: #e6f4ea; color: #137333; }
.alert-msg.error { background: #fce8e6; color: #c5221f; }

@media (max-width: 768px) {
    .form-summary-grid {
        grid-template-columns: 1fr;
    }
    .dates-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<main class="emprestimos-container">
    <h1 class="page-title">Registrar empréstimo / devolução</h1>
    <p class="page-subtitle">Gerencie os empréstimos de livros da biblioteca.</p>

    <?php if (!empty($mensagemSucesso)): ?>
        <div class="alert-msg success"><?= htmlspecialchars($mensagemSucesso, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <?php if (!empty($mensagemErro)): ?>
        <div class="alert-msg error"><?= htmlspecialchars($mensagemErro, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <div class="tabs-container">
        <button class="tab-btn active">Empréstimo</button>
        <button class="tab-btn" onclick="alert('Alterne para devolver na tabela de ativos abaixo.')">Devolução</button>
    </div>

    <!-- formulario de novo emprestimo -->
    <form action="index.php?pagina=novo_emprestimo" method="POST">
        <div class="form-summary-grid">
            <div class="card-box">
                <div class="form-group">
                    <label for="selectUsuario">Usuário</label>
                    <div class="input-search-wrapper">
                        <select name="idUsuario" id="selectUsuario" required onchange="atualizarResumo()">
                            <option value="">Selecione o leitor...</option>
                            <?php foreach ($usuariosLista as $u): ?>
                                <?php 
                                    $nomeLeitor = is_array($u) ? ($u['nome'] ?? $u['nomeUsuario'] ?? 'Leitor') : (string) $u;
                                    $idLeitor = is_array($u) ? ($u['idUsuario'] ?? $u['id'] ?? '') : '';
                                    $matriculaLeitor = is_array($u) ? ($u['matricula'] ?? '123456') : '123456';
                                    $cursoLeitor = is_array($u) ? ($u['curso'] ?? 'Informática') : 'Geral';
                                ?>
                                <option value="<?= htmlspecialchars((string)$idLeitor, ENT_QUOTES, 'UTF-8') ?>" 
                                        data-nome="<?= htmlspecialchars((string)$nomeLeitor, ENT_QUOTES, 'UTF-8') ?>" 
                                        data-matricula="<?= htmlspecialchars((string)$matriculaLeitor, ENT_QUOTES, 'UTF-8') ?>" 
                                        data-curso="<?= htmlspecialchars((string)$cursoLeitor, ENT_QUOTES, 'UTF-8') ?>">
                                    <?= htmlspecialchars((string)$nomeLeitor, ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="selectLivro">Livro</label>
                    <div class="input-search-wrapper">
                        <select name="idLivro" id="selectLivro" required onchange="atualizarResumo()">
                            <option value="">Selecione o livro...</option>
                            <?php foreach ($livrosLista as $l): ?>
                                <?php 
                                    $tituloLivro = is_array($l) ? ($l['titulo'] ?? 'Livro') : (string) $l;
                                    $autorLivro = is_array($l) ? ($l['autor'] ?? 'Autor Desconhecido') : '';
                                    $idLivro = is_array($l) ? ($l['idLivro'] ?? $l['id'] ?? '') : '';
                                ?>
                                <option value="<?= htmlspecialchars((string)$idLivro, ENT_QUOTES, 'UTF-8') ?>" 
                                        data-titulo="<?= htmlspecialchars((string)$tituloLivro, ENT_QUOTES, 'UTF-8') ?>" 
                                        data-autor="<?= htmlspecialchars((string)$autorLivro, ENT_QUOTES, 'UTF-8') ?>">
                                    <?= htmlspecialchars((string)$tituloLivro, ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="dates-grid">
                    <div class="form-group">
                        <label for="dataEmprestimo">Data do empréstimo</label>
                        <div class="input-search-wrapper">
                            <input type="date" id="dataEmprestimo" name="dataEmprestimo" value="<?= $hoje ?>" required onchange="atualizarResumo()">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="dataDevolucao">Data de devolução</label>
                        <div class="input-search-wrapper">
                            <input type="date" id="dataDevolucao" name="dataDevolucao" value="<?= $dataDevPadrao ?>" required onchange="atualizarResumo()">
                        </div>
                    </div>
                </div>
            </div>

            <!-- resumo lateral em tempo real -->
            <div class="card-box gray-bg">
                <h3>Dados do empréstimo</h3>
                
                <div class="summary-item">
                    <label>Usuário</label>
                    <div id="resumoUsuario">Selecione um usuário</div>
                </div>

                <div class="summary-item">
                    <label>Livro</label>
                    <div id="resumoLivro">Selecione um livro</div>
                </div>

                <div class="summary-item">
                    <label>Data do empréstimo</label>
                    <div id="resumoDataEmprestimo">-</div>
                </div>

                <div class="summary-item">
                    <label>Data de devolução</label>
                    <div id="resumoDataDevolucao">-</div>
                </div>

                <button type="submit" class="btn-confirmar-emprestimo">Confirmar Empréstimo</button>
            </div>
        </div>
    </form>

    <!-- tabela de historico e devolucoes -->
    <div class="table-section">
        <h3>Empréstimos ativos</h3>
        <div class="table-wrapper">
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>Livro</th>
                        <th>Data do empréstimo</th>
                        <th>Data de devolução</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($emprestimosAtivos)): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: #777;">Nenhum empréstimo ativo no momento.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($emprestimosAtivos as $emp): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($emp['tituloLivro'] ?? 'Livro', ENT_QUOTES, 'UTF-8') ?></strong><br>
                                    <small style="color: #666;"><?= htmlspecialchars($emp['nomeUsuario'] ?? 'Usuário', ENT_QUOTES, 'UTF-8') ?></small>
                                </td>
                                <td>
                                    <?php 
                                        $dEmp = $emp['dataEmprestimo'] ?? '';
                                        echo $dEmp ? date('d/m/Y', strtotime($dEmp)) : date('d/m/Y');
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                        $dDev = $emp['dataDevolucao'] ?? '';
                                        echo $dDev ? date('d/m/Y', strtotime($dDev)) : date('d/m/Y', strtotime('+14 days'));
                                    ?>
                                </td>
                                <td><span class="status-badge">Em andamento</span></td>
                                <td>
                                    <a href="index.php?pagina=devolver_emprestimo&id=<?= $emp['idEmprestimo'] ?>" 
                                       style="color: #000; font-weight: 600; text-decoration: none;">Devolver</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<script>
//formata data pra mostrar na tela
function formatarDataBR(dataISO) {
    if (!dataISO) return '-';
    const partes = dataISO.split('-');
    if (partes.length === 3) {
        return `${partes[2]}/${partes[1]}/${partes[0]}`;
    }
    return dataISO;
}

//atualiza os dados no card cinza
function atualizarResumo() {
    const selU = document.getElementById('selectUsuario');
    const optU = selU.options[selU.selectedIndex];
    const resU = document.getElementById('resumoUsuario');

    if (selU.value) {
        resU.innerHTML = `<strong>${optU.dataset.nome}</strong><br><small>Matrícula: ${optU.dataset.matricula} | Curso: ${optU.dataset.curso}</small>`;
    } else {
        resU.innerText = 'Selecione um usuário';
    }

    const selL = document.getElementById('selectLivro');
    const optL = selL.options[selL.selectedIndex];
    const resL = document.getElementById('resumoLivro');

    if (selL.value) {
        resL.innerHTML = `<strong>${optL.dataset.titulo}</strong><br><small>Autor: ${optL.dataset.autor}</small>`;
    } else {
        resL.innerText = 'Selecione um livro';
    }

    const inputDataEmp = document.getElementById('dataEmprestimo').value;
    const inputDataDev = document.getElementById('dataDevolucao').value;

    document.getElementById('resumoDataEmprestimo').innerText = formatarDataBR(inputDataEmp);
    document.getElementById('resumoDataDevolucao').innerText = formatarDataBR(inputDataDev);
}

document.addEventListener('DOMContentLoaded', function() {
    atualizarResumo();
});
</script>