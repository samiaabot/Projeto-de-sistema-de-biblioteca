<?php
//inicia a sessao se ainda nao tiver aberta
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

//pega os termos de busca e filtro da url
$buscaAtual = htmlspecialchars((string) ($_GET['busca'] ?? $_GET['pesquisa'] ?? $_GET['termo'] ?? ''), ENT_QUOTES, 'UTF-8');
$categoriaAtual = (string) ($_GET['categoria'] ?? '');
$paginaAtual = (string) ($_GET['pagina'] ?? 'catalogo');

//categorias fixas do menu superior
$categoriasMenu = [
    'Acadêmicos',
    'Clássicos brasileiros',
    'Ficção',
    'Não ficção',
    'Infantil'
];

//busca alguns livros no banco pra mostrar no popup de sugestoes
$sugestoesHeader = [];
if (isset($pdo) && $pdo instanceof PDO) {
    try {
        $stmtSug = $pdo->query("SELECT idLivro, titulo, autor, imagem FROM livros ORDER BY RANDOM() LIMIT 4");
        $sugestoesHeader = $stmtSug->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        $sugestoesHeader = [];
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scriptoria - Biblioteca</title>
    <!-- favicon da logo -->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            color: #1a1a1a;
        }

        .site-header {
            border-bottom: 1px solid #e0e0e0;
            background: #ffffff;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-top {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 20px;
            gap: 20px;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: #1a1a1a;
            font-weight: 700;
            font-size: 1.4rem;
            letter-spacing: -0.5px;
        }

        .brand-logo img {
            height: 32px;
            width: auto;
            object-fit: contain;
        }

        .search-box {
            flex: 1;
            max-width: 480px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 9px 18px;
            padding-right: 70px;
            border: 1px solid #b0b0b0;
            border-radius: 20px;
            font-size: 0.88rem;
            outline: none;
        }

        .search-box button {
            position: absolute;
            right: 6px;
            top: 50%;
            transform: translateY(-50%);
            background: #1a1a1a;
            color: #ffffff;
            border: none;
            border-radius: 14px;
            padding: 5px 12px;
            font-size: 0.75rem;
            font-weight: 600;
            cursor: pointer;
        }

        /* popup de busca dinamico no estilo do wireframe */
        .search-popup {
            display: none;
            position: absolute;
            top: 110%;
            left: 50%;
            transform: translateX(-50%);
            width: 580px;
            max-width: 90vw;
            background: #ffffff;
            border: 1px solid #d0d0d0;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            padding: 24px;
            z-index: 200;
        }

        .search-popup.active {
            display: block;
        }

        .popup-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .popup-section h4 {
            font-size: 0.95rem;
            font-weight: 700;
            margin: 0 0 12px 0;
            color: #000;
        }

        .popup-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .popup-list li {
            margin-bottom: 8px;
        }

        .popup-list a {
            text-decoration: none;
            color: #333;
            font-size: 0.85rem;
            display: block;
        }

        .popup-list a:hover {
            color: #000;
            font-weight: 600;
        }

        .popup-suggestions h4 {
            font-size: 1.1rem;
            font-weight: 700;
            margin: 0 0 14px 0;
        }

        .popup-cards {
            display: flex;
            gap: 14px;
            overflow-x: auto;
        }

        .popup-card-item {
            width: 105px;
            flex-shrink: 0;
            text-align: center;
            text-decoration: none;
            color: inherit;
        }

        .popup-card-box {
            width: 100%;
            height: 135px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background: #f9f9f9;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 6px;
            overflow: hidden;
        }

        .popup-card-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .popup-card-item strong {
            display: block;
            font-size: 0.78rem;
            color: #1a1a1a;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .popup-card-item span {
            display: block;
            font-size: 0.72rem;
            color: #666;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-nav {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-nav a {
            text-decoration: none;
            color: #1a1a1a;
            font-weight: 500;
            font-size: 0.88rem;
        }

        .nav-categories {
            border-top: 1px solid #f0f0f0;
            border-bottom: 1px solid #e0e0e0;
            background: #ffffff;
        }

        .categories-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: center;
            gap: 28px;
            padding: 10px 20px;
            overflow-x: auto;
            white-space: nowrap;
        }

        .category-link {
            text-decoration: none;
            color: #4a4a4a;
            font-size: 0.88rem;
            font-weight: 500;
            padding-bottom: 2px;
        }

        .category-link.active {
            color: #000000;
            font-weight: 700;
            border-bottom: 2px solid #000000;
        }

        .category-link:hover {
            color: #000000;
        }
    </style>
</head>
<body>

<!-- topo do site com logo busca e login -->
<header class="site-header">
    <div class="header-top">
        <a href="index.php" class="brand-logo">
            <img src="assets/img/logo-scriptoria.png" alt="Logo Scriptoria" onerror="this.style.display='none';">
            <span>Scriptoria</span>
        </a>

        <!-- campo de pesquisa com popup de sugestoes -->
        <div class="search-box">
            <form action="index.php" method="GET">
                <input type="text" id="searchInput" name="busca" placeholder="Buscar por título, autor ou categoria..." value="<?= $buscaAtual ?>" autocomplete="off">
                <button type="submit">Buscar</button>
            </form>

            <div class="search-popup" id="searchPopup">
                <div class="popup-grid">
                    <div class="popup-section">
                        <h4>Sugestão de Título</h4>
                        <ul class="popup-list" id="suggestTitles">
                            <?php if (!empty($sugestoesHeader)): ?>
                                <?php foreach (array_slice($sugestoesHeader, 0, 3) as $st): ?>
                                    <li><a href="index.php?busca=<?= urlencode($st['titulo']) ?>"><?= htmlspecialchars($st['titulo'], ENT_QUOTES, 'UTF-8') ?></a></li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li><a href="index.php?busca=Dom+Casmurro">Dom Casmurro</a></li>
                                <li><a href="index.php?busca=Capitães+da+Areia">Capitães da Areia</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="popup-section">
                        <h4>Categorias & Assuntos</h4>
                        <ul class="popup-list">
                            <li><a href="index.php?categoria=Ficção">Ficção</a></li>
                            <li><a href="index.php?categoria=Clássicos+brasileiros">Clássicos brasileiros</a></li>
                            <li><a href="index.php?categoria=Acadêmicos">Acadêmicos</a></li>
                        </ul>
                    </div>
                </div>
                <div class="popup-suggestions">
                    <h4>Sugestões</h4>
                    <div class="popup-cards" id="popupCardsContainer">
                        <?php if (!empty($sugestoesHeader)): ?>
                            <?php foreach ($sugestoesHeader as $sug): ?>
                                <a href="index.php?busca=<?= urlencode($sug['titulo']) ?>" class="popup-card-item">
                                    <div class="popup-card-box">
                                        <svg width="24" height="24" fill="none" stroke="#aaa" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6v14m0-14A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18c-2.305 0-4.408.867-6 2.292"/></svg>
                                    </div>
                                    <strong><?= htmlspecialchars($sug['titulo'], ENT_QUOTES, 'UTF-8') ?></strong>
                                    <span><?= htmlspecialchars($sug['autor'], ENT_QUOTES, 'UTF-8') ?></span>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- links do usuario e adm -->
        <div class="user-nav">
            <?php if (!empty($_SESSION['scriptoria_admin'])): ?>
                <a href="index.php?pagina=admin">Painel Admin</a>
                <a href="index.php?pagina=emprestimos">Empréstimos</a>
                <a href="index.php?pagina=logout">Sair</a>
            <?php else: ?>
                <a href="index.php?pagina=login">Entrar</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- barra de navegacao por categorias -->
    <nav class="nav-categories">
        <div class="categories-container">
            <a href="index.php" class="category-link <?= ($paginaAtual === 'catalogo' && $categoriaAtual === '') ? 'active' : '' ?>">Todos</a>
            <a href="index.php?pagina=populares" class="category-link <?= ($paginaAtual === 'populares') ? 'active' : '' ?>">Populares</a>
            <?php foreach ($categoriasMenu as $cat): ?>
                <a href="index.php?categoria=<?= urlencode($cat) ?>" 
                   class="category-link <?= ($categoriaAtual === $cat) ? 'active' : '' ?>">
                    <?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?>
                </a>
            <?php endforeach; ?>
        </div>
    </nav>
</header>

<script>
//script que abre e fecha o popup ao clicar ou digitar na busca
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const searchPopup = document.getElementById('searchPopup');

    if (searchInput && searchPopup) {
        //abre ao clicar no campo de busca
        searchInput.addEventListener('focus', function() {
            searchPopup.classList.add('active');
        });

        //abre ao digitar algo
        searchInput.addEventListener('input', function() {
            searchPopup.classList.add('active');
        });

        //fecha se clicar fora da caixa de busca
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !searchPopup.contains(e.target)) {
                searchPopup.classList.remove('active');
            }
        });
    }
});
</script>