<?php
//inicia a sessao se ainda nao tiver aberta
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

//pega os termos de busca e filtro da url
$buscaAtual = htmlspecialchars((string) ($_GET['busca'] ?? $_GET['pesquisa'] ?? $_GET['termo'] ?? ''), ENT_QUOTES, 'UTF-8');
$categoriaAtual = (string) ($_GET['categoria'] ?? '');
$paginaAtual = (string) ($_GET['pagina'] ?? 'catalogo');

//categorias fixas do menu superior
$categoriasMenu = [
    'Acadêmicos',
    'Clássicos brasileiros',
    'Ficção',
    'Não ficção',
    'Infantil'
];

//busca alguns livros no banco pra mostrar no popup de sugestoes
$sugestoesHeader = [];
if (isset($pdo) && $pdo instanceof PDO) {
    try {
        $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
        $orderSql = ($driver === 'sqlite') ? "RANDOM()" : "RAND()";
        $stmtSug = $pdo->query("SELECT idLivro, titulo, autor FROM livros ORDER BY {$orderSql} LIMIT 3");
        $sugestoesHeader = $stmtSug->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        $sugestoesHeader = [];
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scriptoria - Biblioteca</title>
    <!-- favicon da logo -->
    <link rel="icon" type="image/png" href="assets/img/favicon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            margin: 0;
            padding: 0;
            background-color: #ffffff;
            color: #1a1a1a;
        }

        .site-header {
            border-bottom: 1px solid #e0e0e0;
            background: #ffffff;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-top {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            padding: 14px 20px;
            gap: 20px;
        }

        .btn-sair {
            flex-shrink: 0; 
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: #1a1a1a;
            font-weight: 700;
            font-size: 1.4rem;
            letter-spacing: -0.5px;
        }

        .brand-logo img {
            height: 32px;
            width: auto;
            object-fit: contain;
        }

        .search-box {
            flex: 1;
            max-width: 480px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 9px 18px;
            padding-right: 70px;
            border: 1px solid #b0b0b0;
            border-radius: 20px;
            font-size: 0.88rem;
            outline: none;
        }

        .search-box button {
            position: absolute;
            right: 6px;
            top: 50%;
            transform: translateY(-50%);
            background: #1a1a1a;
            color: #ffffff;
            border: none;
            border-radius: 14px;
            padding: 5px 12px;
            font-size: 0.75rem;
            font-weight: 600;
            cursor: pointer;
        }

        .search-popup {
            display: none;
            position: absolute;
            top: 110%;
            left: 50%;
            transform: translateX(-50%);
            width: 580px;
            max-width: 90vw;
            background: #ffffff;
            border: 1px solid #d0d0d0;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            padding: 24px;
            z-index: 200;
        }

        .search-popup.active {
            display: block;
        }

        .popup-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 0;
        }

        .popup-section h4 {
            font-size: 0.95rem;
            font-weight: 700;
            margin: 0 0 12px 0;
            color: #000;
        }

        .popup-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .popup-list li {
            margin-bottom: 8px;
        }

        .popup-list a {
            text-decoration: none;
            color: #333;
            font-size: 0.85rem;
            display: block;
        }

        .popup-list a:hover {
            color: #000;
            font-weight: 600;
        }

        .user-nav {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-nav a {
            text-decoration: none;
            color: #1a1a1a;
            font-weight: 500;
            font-size: 0.88rem;
        }

        .nav-categories {
            border-top: 1px solid #f0f0f0;
            border-bottom: 1px solid #e0e0e0;
            background: #ffffff;
        }

        .categories-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: center;
            gap: 28px;
            padding: 10px 20px;
            overflow-x: auto;
            white-space: nowrap;
        }

        .category-link {
            text-decoration: none;
            color: #4a4a4a;
            font-size: 0.88rem;
            font-weight: 500;
            padding-bottom: 2px;
        }

        .category-link.active {
            color: #000000;
            font-weight: 700;
            border-bottom: 2px solid #000000;
        }

        .category-link:hover {
            color: #000000;
        }
    </style>
</head>
<body>

<!-- topo do site com logo busca e login -->
<header class="site-header">
    <div class="header-top">
        <a href="index.php" class="brand-logo">
            <img src="assets/img/logo-scriptoria.png" alt="Logo Scriptoria" onerror="this.style.display='none';">
            <span>Scriptoria</span>
        </a>

        <!-- campo de pesquisa com popup de sugestoes -->
        <div class="search-box">
            <form action="index.php" method="GET">
                <input type="text" id="searchInput" name="busca" placeholder="Buscar por título, autor ou categoria..." value="<?= $buscaAtual ?>" autocomplete="off">
                <button type="submit">Buscar</button>
            </form>

            <div class="search-popup" id="searchPopup">
                <div class="popup-grid">
                    <div class="popup-section">
                        <h4>Sugestão de Título</h4>
                        <ul class="popup-list" id="suggestTitles">
                            <?php if (!empty($sugestoesHeader)): ?>
                                <?php foreach ($sugestoesHeader as $st): ?>
                                    <li><a href="index.php?busca=<?= urlencode($st['titulo']) ?>"><?= htmlspecialchars($st['titulo'], ENT_QUOTES, 'UTF-8') ?></a></li>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <li><a href="index.php?busca=Dom+Casmurro">Dom Casmurro</a></li>
                                <li><a href="index.php?busca=Capitães+da+Areia">Capitães da Areia</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="popup-section">
                        <h4>Categorias & Assuntos</h4>
                        <ul class="popup-list">
                            <li><a href="index.php?categoria=Ficção">Ficção</a></li>
                            <li><a href="index.php?categoria=Clássicos+brasileiros">Clássicos brasileiros</a></li>
                            <li><a href="index.php?categoria=Acadêmicos">Acadêmicos</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- links do usuario e adm -->
        <div class="user-nav">
            <?php if (!empty($_SESSION['scriptoria_admin'])): ?>
                <a href="index.php?pagina=admin">Painel Admin</a>
                <a href="index.php?pagina=emprestimos">Empréstimos</a>
                <a href="index.php?pagina=logout">Sair</a>
            <?php else: ?>
                <a href="index.php?pagina=login">Entrar</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- barra de navegacao por categorias -->
    <nav class="nav-categories">
        <div class="categories-container">
            <a href="index.php" class="category-link <?= ($paginaAtual === 'catalogo' && $categoriaAtual === '') ? 'active' : '' ?>">Todos</a>
            <a href="index.php?pagina=populares" class="category-link <?= ($paginaAtual === 'populares') ? 'active' : '' ?>">Populares</a>
            <?php foreach ($categoriasMenu as $cat): ?>
                <a href="index.php?categoria=<?= urlencode($cat) ?>" 
                   class="category-link <?= ($categoriaAtual === $cat) ? 'active' : '' ?>">
                    <?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?>
                </a>
            <?php endforeach; ?>
        </div>
    </nav>
</header>