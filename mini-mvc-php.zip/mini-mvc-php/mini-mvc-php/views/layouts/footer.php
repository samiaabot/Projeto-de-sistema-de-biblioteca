<footer style="border-top: 1px solid #e0e0e0; margin-top: 60px; padding: 25px 20px; text-align: center; color: #888888; font-size: 0.82rem;">
    <div style="max-width: 1200px; margin: 0 auto;">
        <p style="margin: 0;">&copy; <?= date('Y') ?> Scriptoria - Sistema de Gestão de Biblioteca</p>
    </div>
</footer>

<script>
//script que abre e fecha o popup ao clicar ou digitar na busca
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const searchPopup = document.getElementById('searchPopup');
    const popupCardsContainer = document.getElementById('popupCardsContainer');
    const suggestTitles = document.getElementById('suggestTitles');

    if (searchInput && searchPopup) {
        //abre ao clicar no campo de busca
        searchInput.addEventListener('focus', function() {
            searchPopup.classList.add('active');
        });

        //abre ao digitar algo
        searchInput.addEventListener('input', function() {
            searchPopup.classList.add('active');
            const termo = this.value.trim();

            if (termo.length >= 2) {
                fetch(`index.php?pagina=buscar-ajax&q=${encodeURIComponent(termo)}`)
                    .then(response => response.json())
                    .then(data => {
                        if (popupCardsContainer && data && data.length > 0) {
                            popupCardsContainer.innerHTML = '';
                            if (suggestTitles) suggestTitles.innerHTML = '';

                            data.forEach(livro => {
                                const imgPath = livro.imagem ? livro.imagem : 'assets/img/logo-scriptoria.png';

                                if (suggestTitles) {
                                    const li = document.createElement('li');
                                    li.innerHTML = `<a href="index.php?busca=${encodeURIComponent(livro.titulo)}">${livro.titulo}</a>`;
                                    suggestTitles.appendChild(li);
                                }

                                const card = document.createElement('a');
                                card.href = `index.php?busca=${encodeURIComponent(livro.titulo)}`;
                                card.className = 'popup-card-item';
                                card.innerHTML = `
                                    <div class="popup-card-box">
                                        <img src="${imgPath}" alt="${livro.titulo}">
                                    </div>
                                    <strong>${livro.titulo}</strong>
                                    <span>${livro.autor}</span>
                                `;
                                popupCardsContainer.appendChild(card);
                            });
                        }
                    })
                    .catch(err => console.error(err));
            }
        });

        //fecha se clicar fora da caixa de busca
        document.addEventListener('click', function(e) {
            if (!searchInput.contains(e.target) && !searchPopup.contains(e.target)) {
                searchPopup.classList.remove('active');
            }
        });
    }
});
</script>

</body>
</html>