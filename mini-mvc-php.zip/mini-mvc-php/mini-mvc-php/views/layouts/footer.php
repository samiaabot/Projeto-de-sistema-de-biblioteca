<footer style="border-top: 1px solid #e0e0e0; margin-top: 60px; padding: 25px 20px; text-align: center; color: #888888; font-size: 0.82rem;">
    <div style="max-width: 1200px; margin: 0 auto;">
        <p style="margin: 0;">&copy; <?= date('Y') ?> Scriptoria - Sistema de Gestão de Biblioteca</p>
    </div>
</footer>
</body>
</html>