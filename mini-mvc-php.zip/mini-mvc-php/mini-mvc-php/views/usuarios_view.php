<?php
//limpa o texto pra nao dar erro de xss
function scriptoriaUsrEscapar($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

//mensagens de retorno da tela
$msg = (string) ($_GET['msg'] ?? '');
$mensagens = [
    'salvo'     => 'Leitor salvo com sucesso!',
    'excluido'  => 'Leitor excluído com sucesso.',
    'bloqueado' => 'Não foi possível excluir. O leitor possui empréstimos registrados no histórico.',
    'erro'      => 'Não foi possível concluir a operação. Confira os dados e tente novamente.'
];

//pega leitores do banco e ve se ta editando alguem
$listaUsuarios = is_array($usuarios ?? null) ? $usuarios : [];
$usrEdicao     = is_array($usuarioEdicao ?? null) ? $usuarioEdicao : [];
$editando      = !empty($usrEdicao['id']);
?>

<style>
.scriptoria-usuarios {
    max-width: 1150px;
    margin: 0 auto;
    padding: 30px 20px 50px;
    color: #493526;
}
.scriptoria-usuarios h1, .scriptoria-usuarios h2 {
    color: #493526;
}
.scriptoria-usuarios .painel {
    background: #fffdf8;
    border: 1px solid #e8ddcc;
    border-radius: 14px;
    padding: 24px;
    margin: 22px 0;
}
.scriptoria-usuarios .formulario {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 16px;
}
.scriptoria-usuarios .campo {
    display: flex;
    flex-direction: column;
    gap: 7px;
}
.scriptoria-usuarios input {
    width: 100%;
    box-sizing: border-box;
    padding: 11px;
    border: 1px solid #dfcbb4;
    border-radius: 8px;
    background: #fff;
    font: inherit;
}
.scriptoria-usuarios .botoes {
    grid-column: 1 / -1;
    display: flex;
    gap: 10px;
    margin-top: 10px;
}
.scriptoria-usuarios .botao {
    display: inline-block;
    border: 0;
    border-radius: 8px;
    padding: 10px 16px;
    background: #55765e;
    color: white;
    cursor: pointer;
    font: inherit;
    text-decoration: none;
}
.scriptoria-usuarios .botao.secundario {
    background: #e9dfd1;
    color: #493526;
}
.scriptoria-usuarios .botao.perigo {
    background: #9c3e34;
}
.scriptoria-usuarios .aviso {
    background: #edf1e9;
    border-radius: 8px;
    padding: 13px;
    margin-bottom: 20px;
}
.scriptoria-usuarios .tabela-wrapper {
    overflow-x: auto;
}
.scriptoria-usuarios table {
    width: 100%;
    border-collapse: collapse;
    text-align: left;
}
.scriptoria-usuarios th, .scriptoria-usuarios td {
    padding: 12px;
    border-bottom: 1px solid #eadcc9;
    vertical-align: top;
}
.scriptoria-usuarios th {
    background: #f7efe3;
}
.scriptoria-usuarios .acoes {
    display: flex;
    gap: 7px;
}
@media (max-width: 768px) {
    .scriptoria-usuarios .formulario {
        grid-template-columns: 1fr;
    }
}
</style>

<main class="scriptoria-usuarios">
    <h1>Gerir leitores</h1>
    <p>Cadastre e atualize as informações dos alunos e leitores da biblioteca.</p>

    <!-- mostra o aviso se tiver alguma msg -->
    <?php if (isset($mensagens[$msg])): ?>
        <p class="aviso" role="status">
            <?= scriptoriaUsrEscapar($mensagens[$msg]) ?>
        </p>
    <?php endif; ?>

    <!-- form pra criar ou editar leitor -->
    <section class="painel">
        <h2><?= $editando ? 'Editar leitor' : 'Cadastrar leitor' ?></h2>

        <form class="formulario" method="POST" action="index.php?pagina=usuarios">
            <input type="hidden" name="csrf_token" value="<?= scriptoriaUsrEscapar($csrfToken ?? '') ?>">
            <input type="hidden" name="acao" value="salvar">
            <input type="hidden" name="idUsuario" value="<?= scriptoriaUsrEscapar($usrEdicao['id'] ?? '') ?>">

            <div class="campo">
                <label for="nome">Nome completo *</label>
                <input id="nome" name="nome" maxlength="150" required
                       value="<?= scriptoriaUsrEscapar($usrEdicao['nome'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="email">E-mail *</label>
                <input id="email" name="email" type="email" maxlength="150" required
                       value="<?= scriptoriaUsrEscapar($usrEdicao['email'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="telefone">Telefone / WhatsApp *</label>
                <input id="telefone" name="telefone" maxlength="20" required
                       placeholder="(55) 99999-9999"
                       value="<?= scriptoriaUsrEscapar($usrEdicao['telefone'] ?? '') ?>">
            </div>

            <div class="botoes">
                <button class="botao" type="submit">
                    <?= $editando ? 'Salvar alterações' : 'Cadastrar leitor' ?>
                </button>

                <?php if ($editando): ?>
                    <a class="botao secundario" href="index.php?pagina=usuarios">Cancelar edição</a>
                <?php endif; ?>

                <a class="botao secundario" href="index.php?pagina=admin">Voltar ao painel</a>
            </div>
        </form>
    </section>

    <!-- tabela que lista todo mundo -->
    <section class="painel">
        <h2>Leitores cadastrados (<?= count($listaUsuarios) ?>)</h2>

        <?php if (empty($listaUsuarios)): ?>
            <p>Nenhum leitor cadastrado no banco de dados.</p>
        <?php else: ?>
            <div class="tabela-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>Telefone</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($listaUsuarios as $u): ?>
                        <tr>
                            <td><strong><?= scriptoriaUsrEscapar($u['nome']) ?></strong></td>
                            <td><?= scriptoriaUsrEscapar($u['email']) ?></td>
                            <td><?= scriptoriaUsrEscapar($u['telefone']) ?></td>
                            <td>
                                <div class="acoes">
                                    <a class="botao" href="index.php?pagina=usuarios&acao=editar&id=<?= (int) $u['id'] ?>">
                                        Editar
                                    </a>

                                    <form method="POST" action="index.php?pagina=usuarios" onsubmit="return confirm('Deseja excluir este leitor?');">
                                        <input type="hidden" name="csrf_token" value="<?= scriptoriaUsrEscapar($csrfToken ?? '') ?>">
                                        <input type="hidden" name="acao" value="excluir">
                                        <input type="hidden" name="idUsuario" value="<?= (int) $u['id'] ?>">
                                        <button class="botao perigo" type="submit">Excluir</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>