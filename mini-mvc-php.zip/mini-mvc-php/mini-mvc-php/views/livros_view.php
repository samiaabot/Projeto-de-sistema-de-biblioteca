<?php
//remove os acentos e coloca o texto em minúsuculo pra bater com o nome do arquivo
function scriptoriaNormalizarTexto(string $texto): string {
    $texto = mb_strtolower($texto, 'UTF-8');
    $mapa = [
        'á'=>'a', 'à'=>'a', 'ã'=>'a', 'â'=>'a', 'ä'=>'a',
        'é'=>'e', 'è'=>'e', 'ê'=>'e', 'ë'=>'e',
        'í'=>'i', 'ì'=>'i', 'î'=>'i', 'ï'=>'i',
        'ó'=>'o', 'ò'=>'o', 'õ'=>'o', 'ô'=>'o', 'ö'=>'o',
        'ú'=>'u', 'ù'=>'u', 'û'=>'u', 'ü'=>'u',
        'ç'=>'c', 'ñ'=>'n'
    ];
    $texto = strtr($texto, $mapa);
    return preg_replace('/[^a-z0-9]/', '', $texto);
}

//busca a capa recursivamente nas subpastas caso o caminho do banco falhar
function scriptoriaCapaView(array $livro): string {
    $caminho = trim((string) ($livro['imagem'] ?? ''));
    $titulo = trim((string) ($livro['titulo'] ?? ''));

    if ($caminho !== '') {
        $caminhoLimpo = ltrim($caminho, '/\\');
        if (file_exists(__DIR__ . '/../' . $caminhoLimpo)) {
            return $caminhoLimpo;
        }
    }

    $diretorioBase = __DIR__ . '/../assets/img/livros/';
    
    if (is_dir($diretorioBase)) {
        $nomeBuscadoNorm = $caminho !== '' ? scriptoriaNormalizarTexto(basename($caminho)) : '';
        $tituloNorm = scriptoriaNormalizarTexto($titulo);

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($diretorioBase, RecursiveDirectoryIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $nomeArquivo = $file->getFilename();
                $nomeSemExt = pathinfo($nomeArquivo, PATHINFO_FILENAME);
                $nomeArquivoNorm = scriptoriaNormalizarTexto($nomeSemExt);

                if ($nomeBuscadoNorm !== '' && $nomeArquivoNorm === $nomeBuscadoNorm) {
                    $rel = str_replace('\\', '/', substr($file->getPathname(), strlen(__DIR__ . '/../')));
                    return ltrim($rel, '/');
                }

                if ($tituloNorm !== '' && (strpos($nomeArquivoNorm, $tituloNorm) !== false || strpos($tituloNorm, $nomeArquivoNorm) !== false)) {
                    $rel = str_replace('\\', '/', substr($file->getPathname(), strlen(__DIR__ . '/../')));
                    return ltrim($rel, '/');
                }
            }
        }
    }

    return '';
}

//captura os parametros da url pra filtrar
$buscaTermo = htmlspecialchars((string) ($_GET['busca'] ?? $_GET['pesquisa'] ?? $_GET['termo'] ?? ''), ENT_QUOTES, 'UTF-8');
$categoriaSel = htmlspecialchars((string) ($_GET['categoria'] ?? ''), ENT_QUOTES, 'UTF-8');
?>

<style>
.catalog-container {
    max-width: 1200px;
    margin: 40px auto;
    padding: 0 20px;
}

.catalog-header {
    text-align: center;
    margin-bottom: 40px;
}

.catalog-header h1 {
    font-size: 1.75rem;
    font-weight: 700;
    margin-bottom: 8px;
    color: #1a1a1a;
}

.catalog-header p {
    color: #666666;
    font-size: 0.92rem;
    margin: 0;
}

.books-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 32px 24px;
    justify-content: center;
}

.book-card {
    display: flex;
    flex-direction: column;
    cursor: pointer;
}

.book-cover-wrapper {
    width: 100%;
    aspect-ratio: 2 / 3;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    overflow: hidden;
    background: #f4f4f4;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 12px;
}

.book-cover-wrapper img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.book-cover-placeholder {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 15px;
    text-align: center;
    color: #999999;
    height: 100%;
    width: 100%;
    box-sizing: border-box;
}

.book-cover-placeholder svg {
    width: 42px;
    height: 42px;
    margin-bottom: 8px;
    stroke: #aaaaaa;
}

.book-cover-placeholder span {
    font-size: 0.75rem;
    font-weight: 500;
    line-height: 1.2;
    color: #777777;
}

.book-info h3 {
    font-size: 0.92rem;
    font-weight: 600;
    margin: 0 0 4px 0;
    color: #1a1a1a;
    line-height: 1.3;
}

.book-info p {
    font-size: 0.82rem;
    color: #666666;
    margin: 0;
}

.empty-catalog {
    text-align: center;
    padding: 60px 20px;
    color: #666666;
}

.book-modal-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 1000;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.book-modal-overlay.active {
    display: flex;
}

.book-modal-content {
    background: #ffffff;
    border-radius: 8px;
    max-width: 850px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
    padding: 35px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
}

.modal-close-btn {
    position: absolute;
    top: 15px;
    right: 20px;
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #666;
}

.modal-body {
    display: grid;
    grid-template-columns: 240px 1fr;
    gap: 30px;
}

.modal-cover {
    width: 100%;
    aspect-ratio: 2 / 3;
    border: 1px solid #ddd;
    border-radius: 4px;
    overflow: hidden;
    background: #f8f8f8;
}

.modal-cover img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.modal-details h2 {
    font-size: 1.6rem;
    font-weight: 700;
    margin: 0 0 6px 0;
    color: #1a1a1a;
}

.modal-details .modal-author {
    font-size: 1rem;
    color: #666;
    margin-bottom: 15px;
}

.modal-badge {
    display: inline-block;
    background: #e8e8e8;
    padding: 6px 14px;
    border-radius: 4px;
    font-size: 0.85rem;
    font-weight: 500;
    margin-bottom: 20px;
}

.modal-actions {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
}

.btn-action {
    padding: 8px 18px;
    border-radius: 4px;
    font-size: 0.85rem;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid #777;
    background: #666;
    color: #fff;
}

.btn-action.secondary {
    background: #e8e8e8;
    color: #333;
    border: 1px solid #ccc;
}

.modal-synopsis {
    font-size: 0.88rem;
    line-height: 1.6;
    color: #444;
    margin-bottom: 25px;
}

.modal-meta-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    border-top: 1px solid #eee;
    padding-top: 15px;
    gap: 15px;
}

.meta-item {
    border-right: 1px solid #eee;
    padding-right: 10px;
}

.meta-item:last-child {
    border-right: none;
}

.meta-item span {
    display: block;
    font-size: 0.75rem;
    color: #888;
}

.meta-item strong {
    font-size: 0.85rem;
    color: #1a1a1a;
}

@media (max-width: 650px) {
    .modal-body {
        grid-template-columns: 1fr;
    }
}
</style>

<!-- cabecalho do catalogo -->
<main class="catalog-container">
    <div class="catalog-header">
        <h1>
            <?php 
                if (!empty($categoriaSel)) {
                    echo $categoriaSel;
                } elseif (!empty($tituloPagina)) {
                    echo $tituloPagina;
                } else {
                    echo "Catálogo de Livros";
                }
            ?>
        </h1>
        <?php if (!empty($buscaTermo)): ?>
            <p>Resultados da busca por: <strong>"<?= $buscaTermo ?>"</strong></p>
        <?php else: ?>
            <p>Explore as obras e títulos disponíveis na biblioteca.</p>
        <?php endif; ?>
    </div>

    <!-- mostra a grade de livros ou aviso de catalogo vazio -->
    <?php if (empty($livros)): ?>
        <div class="empty-catalog">
            <p>Nenhum livro foi encontrado com os critérios selecionados.</p>
        </div>
    <?php else: ?>
        <div class="books-grid">
            <?php foreach ($livros as $l): ?>
                <?php 
                    $capaUrl = scriptoriaCapaView($l); 
                    $autorExibir = trim((string)($l['autor'] ?? ''));
                    if (mb_stripos($autorExibir, 'confirmar') !== false) {
                        $autorExibir = 'Autor não informado';
                    }
                ?>
                <!-- card do livro com clique pra abrir o modal -->
                <div class="book-card" onclick="openBookModal(<?= htmlspecialchars(json_encode([
                    'titulo' => $l['titulo'],
                    'autor' => $autorExibir,
                    'status' => $l['status'] ?? 'DISPONIVEL',
                    'localizacao' => $l['localizacao'] ?? 'Estante Principal',
                    'sinopse' => !empty($l['sinopse']) ? $l['sinopse'] : 'Sem sinopse disponível para este título no momento.',
                    'categoria' => $l['categoria'] ?? 'Geral',
                    'ano' => $l['anoPublicacao'] ?? '-',
                    'capa' => $capaUrl
                ]), ENT_QUOTES, 'UTF-8') ?>)">
                    <div class="book-cover-wrapper">
                        <?php if ($capaUrl !== ''): ?>
                            <img src="<?= htmlspecialchars($capaUrl, ENT_QUOTES, 'UTF-8') ?>" 
                                 alt="<?= htmlspecialchars($l['titulo'], ENT_QUOTES, 'UTF-8') ?>"
                                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <div class="book-cover-placeholder" style="display: none;">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18c-2.305 0-4.408.867-6 2.292m0-14.25v14.25" />
                                </svg>
                                <span><?= htmlspecialchars($l['titulo'], ENT_QUOTES, 'UTF-8') ?></span>
                            </div>
                        <?php else: ?>
                            <div class="book-cover-placeholder">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18c-2.305 0-4.408.867-6 2.292m0-14.25v14.25" />
                                </svg>
                                <span><?= htmlspecialchars($l['titulo'], ENT_QUOTES, 'UTF-8') ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="book-info">
                        <h3><?= htmlspecialchars($l['titulo'], ENT_QUOTES, 'UTF-8') ?></h3>
                        <p><?= htmlspecialchars($autorExibir, ENT_QUOTES, 'UTF-8') ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<!-- modal dinamico com os detalhes do livro -->
<div class="book-modal-overlay" id="bookModal">
    <div class="book-modal-content">
        <button class="modal-close-btn" onclick="closeBookModal()">&times;</button>
        <div class="modal-body">
            <div class="modal-cover" id="modalCoverContainer">
                <img id="modalCoverImg" src="" alt="Capa">
            </div>
            <div class="modal-details">
                <h2 id="modalTitle">Título do Livro</h2>
                <div class="modal-author" id="modalAuthor">Nome do Autor</div>

                <div class="modal-badge" id="modalLocation">Disponível | Estante 04</div>

                <div class="modal-actions">
                    <button class="btn-action">Verificar disponibilidade</button>
                    <button class="btn-action secondary">Pré-visualização</button>
                </div>

                <div class="modal-synopsis">
                    <strong>Sobre o livro:</strong>
                    <p id="modalSynopsisText">Descrição do livro...</p>
                </div>

                <div class="modal-meta-grid">
                    <div class="meta-item">
                        <span>Editora</span>
                        <strong>Editora Padrão</strong>
                    </div>
                    <div class="meta-item">
                        <span>Categoria</span>
                        <strong id="modalCategory">Geral</strong>
                    </div>
                    <div class="meta-item">
                        <span>Ano de publicação</span>
                        <strong id="modalYear">2020</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
//funcoes em js pra abrir e fechar a janela do livro
function openBookModal(book) {
    document.getElementById('modalTitle').innerText = book.titulo;
    document.getElementById('modalAuthor').innerText = book.autor;
    document.getElementById('modalLocation').innerText = (book.status === 'DISPONIVEL' ? 'Disponível' : 'Indisponível') + ' | ' + book.localizacao;
    document.getElementById('modalSynopsisText').innerText = book.sinopse;
    document.getElementById('modalCategory').innerText = book.categoria;
    document.getElementById('modalYear').innerText = book.ano;

    const imgElem = document.getElementById('modalCoverImg');
    if (book.capa) {
        imgElem.src = book.capa;
        imgElem.style.display = 'block';
    } else {
        imgElem.style.display = 'none';
    }

    document.getElementById('bookModal').classList.add('active');
}

function closeBookModal() {
    document.getElementById('bookModal').classList.remove('active');
}

document.getElementById('bookModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeBookModal();
    }
});
</script>