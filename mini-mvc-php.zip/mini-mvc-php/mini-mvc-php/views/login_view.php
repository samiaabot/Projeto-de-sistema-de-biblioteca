<?php
//inicia sessao pra controlar o login
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

//pega os dados enviados no post e valida o adm
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim((string) ($_POST['usuario'] ?? ''));
    $senha = trim((string) ($_POST['senha'] ?? ''));

    if ($usuario === 'admin' && $senha === 'info4') {
        $_SESSION['scriptoria_admin'] = true;
        header('Location: index.php?pagina=admin');
        exit;
    } else {
        $erro = 'Credenciais inválidas.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Scriptoria</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body {
            background-color: #f4f4f4;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        .login-card {
            background: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 40px;
            width: 100%;
            max-width: 380px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            text-align: center;
        }
        .login-card img {
            height: 48px;
            margin-bottom: 12px;
        }
        .login-card h2 {
            margin: 0 0 6px 0;
            font-size: 1.4rem;
            color: #1a1a1a;
        }
        .login-card p {
            font-size: 0.85rem;
            color: #666666;
            margin-bottom: 25px;
        }
        .form-group {
            text-align: left;
            margin-bottom: 18px;
        }
        .form-group label {
            display: block;
            font-size: 0.8rem;
            font-weight: 600;
            margin-bottom: 6px;
            color: #333333;
        }
        .form-group input {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid #cccccc;
            border-radius: 4px;
            font-size: 0.88rem;
            outline: none;
        }
        .btn-submit {
            width: 100%;
            padding: 11px;
            background: #1a1a1a;
            color: #ffffff;
            border: none;
            border-radius: 4px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            margin-top: 10px;
        }
        .error-msg {
            background: #fce8e6;
            color: #c5221f;
            padding: 10px;
            border-radius: 4px;
            font-size: 0.82rem;
            margin-bottom: 18px;
        }
    </style>
</head>
<body>

<!-- card central de login -->
<div class="login-card">
    <img src="assets/img/logo-scriptoria.png" alt="Scriptoria" onerror="this.style.display='none';">
    <h2>Scriptoria</h2>
    <p>Acesse o painel administrativo</p>

    <!-- aviso caso erre a senha -->
    <?php if ($erro !== ''): ?>
        <div class="error-msg"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <!-- form de acesso do adm -->
    <form action="index.php?pagina=login" method="POST">
        <div class="form-group">
            <label for="usuario">Usuário</label>
            <input type="text" id="usuario" name="usuario" required placeholder="Digite seu usuário">
        </div>
        <div class="form-group">
            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" required placeholder="Digite sua senha">
        </div>
        <button type="submit" class="btn-submit">Entrar</button>
    </form>
</div>

</body>
</html>