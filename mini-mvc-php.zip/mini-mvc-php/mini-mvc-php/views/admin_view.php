<?php
//valores padrao pras estatisticas do painel
$totalLivros = $totalLivros ?? 0;
$totalDisponiveis = $totalDisponiveis ?? 0;
$totalUsuarios = $totalUsuarios ?? 0;
$totalEmprestimos = $totalEmprestimos ?? 0;
?>

<style>
.admin-container {
    max-width: 1200px;
    margin: 40px auto;
    padding: 0 20px;
}

.admin-header {
    margin-bottom: 35px;
}

.admin-header h1 {
    font-size: 1.75rem;
    font-weight: 700;
    margin: 0 0 6px 0;
    color: #1a1a1a;
}

.admin-header p {
    color: #666666;
    font-size: 0.9rem;
    margin: 0;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}

.stat-card {
    background: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 24px;
    text-align: left;
}

.stat-card h3 {
    font-size: 0.82rem;
    font-weight: 600;
    color: #666666;
    margin: 0 0 8px 0;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.stat-card .number {
    font-size: 1.8rem;
    font-weight: 700;
    color: #1a1a1a;
    margin: 0;
}

.quick-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
}

.action-card {
    background: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 24px;
    text-decoration: none;
    color: inherit;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    transition: border-color 0.2s ease;
}

.action-card:hover {
    border-color: #1a1a1a;
}

.action-card h2 {
    font-size: 1.1rem;
    font-weight: 700;
    margin: 0 0 8px 0;
    color: #1a1a1a;
}

.action-card p {
    font-size: 0.85rem;
    color: #666666;
    margin: 0 0 20px 0;
    line-height: 1.4;
}

.action-card .btn-link {
    font-size: 0.85rem;
    font-weight: 600;
    color: #1a1a1a;
}
</style>

<main class="admin-container">
    <div class="admin-header">
        <h1>Painel de Controle</h1>
        <p>Visão geral da biblioteca e atalhos de gestão.</p>
    </div>

    <!-- cards com totais e estatisticas do sistema -->
    <div class="stats-grid">
        <div class="stat-card">
            <h3>Livros Cadastrados</h3>
            <p class="number"><?= $totalLivros ?></p>
        </div>
        <div class="stat-card">
            <h3>Livros Disponíveis</h3>
            <p class="number"><?= $totalDisponiveis ?></p>
        </div>
        <div class="stat-card">
            <h3>Leitores / Usuários</h3>
            <p class="number"><?= $totalUsuarios ?></p>
        </div>
        <div class="stat-card">
            <h3>Empréstimos Ativos</h3>
            <p class="number"><?= $totalEmprestimos ?></p>
        </div>
    </div>

    <!-- atalhos pras principais telas do adm -->
    <div class="quick-actions-grid">
        <a href="index.php?pagina=livros" class="action-card">
            <div>
                <h2>Gerenciar Livros</h2>
                <p>Adicione, edite ou remova títulos do acervo da biblioteca.</p>
            </div>
            <span class="btn-link">Acessar catálogo &rarr;</span>
        </a>

        <a href="index.php?pagina=usuarios" class="action-card">
            <div>
                <h2>Gerenciar Leitores</h2>
                <p>Cadastre novos leitores, alunos ou professores no sistema.</p>
            </div>
            <span class="btn-link">Acessar leitores &rarr;</span>
        </a>

        <a href="index.php?pagina=emprestimos" class="action-card">
            <div>
                <h2>Empréstimos e Devoluções</h2>
                <p>Registre novos empréstimos de livros e controle prazos.</p>
            </div>
            <span class="btn-link">Registrar empréstimo &rarr;</span>
        </a>
    </div>
</main>