<?php
//trata xss nos dados exibidos
function scriptoriaEscapar($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

//alertas de feedback do sistema
$msg = (string) ($_GET['msg'] ?? '');
$mensagens = [
    'salvo'     => 'Livro salvo com sucesso!',
    'excluido'  => 'Livro excluído com sucesso.',
    'bloqueado' => 'Não foi possível excluir o livro porque ele possui histórico ou está emprestado.',
    'erro'      => 'Não foi possível concluir a operação. Confira os dados e tente novamente.'
];

//inicializa dados e verifica se e edicao
$listaLivros = is_array($livros ?? null) ? $livros : [];
$livroEd     = is_array($livroEdicao ?? null) ? $livroEdicao : [];
$editando    = !empty($livroEd['idLivro']);

$categoriasOpcoes = [
    'Acadêmicos',
    'Clássicos brasileiros',
    'Ficção',
    'Não ficção',
    'Infantil'
];
?>

<style>
.scriptoria-gerir {
    max-width: 1150px;
    margin: 0 auto;
    padding: 30px 20px 50px;
    color: #493526;
}
.scriptoria-gerir h1, .scriptoria-gerir h2 {
    color: #493526;
}
.scriptoria-gerir .painel {
    background: #fffdf8;
    border: 1px solid #e8ddcc;
    border-radius: 14px;
    padding: 24px;
    margin: 22px 0;
}
.scriptoria-gerir .formulario {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 16px;
}
.scriptoria-gerir .campo {
    display: flex;
    flex-direction: column;
    gap: 7px;
}
.scriptoria-gerir .campo.full {
    grid-column: 1 / -1;
}
.scriptoria-gerir select, .scriptoria-gerir input, .scriptoria-gerir textarea {
    width: 100%;
    box-sizing: border-box;
    padding: 11px;
    border: 1px solid #dfcbb4;
    border-radius: 8px;
    background: #fff;
    font: inherit;
}
.scriptoria-gerir textarea {
    resize: vertical;
    min-height: 80px;
}
.scriptoria-gerir .botoes {
    grid-column: 1 / -1;
    display: flex;
    gap: 10px;
    margin-top: 10px;
}
.scriptoria-gerir .botao {
    display: inline-block;
    border: 0;
    border-radius: 8px;
    padding: 10px 16px;
    background: #55765e;
    color: white;
    cursor: pointer;
    font: inherit;
    text-decoration: none;
}
.scriptoria-gerir .botao.secundario {
    background: #e9dfd1;
    color: #493526;
}
.scriptoria-gerir .botao.perigo {
    background: #9c3e34;
}
.scriptoria-gerir .aviso {
    background: #edf1e9;
    border-radius: 8px;
    padding: 13px;
    margin-bottom: 20px;
}
.scriptoria-gerir .tabela-wrapper {
    overflow-x: auto;
}
.scriptoria-gerir table {
    width: 100%;
    border-collapse: collapse;
    text-align: left;
}
.scriptoria-gerir th, .scriptoria-gerir td {
    padding: 12px;
    border-bottom: 1px solid #eadcc9;
    vertical-align: top;
}
.scriptoria-gerir th {
    background: #f7efe3;
}
.scriptoria-gerir .acoes {
    display: flex;
    gap: 7px;
}
@media (max-width: 768px) {
    .scriptoria-gerir .formulario {
        grid-template-columns: 1fr;
    }
}
</style>

<main class="scriptoria-gerir">
    <h1>Gerir acervo de livros</h1>
    <p>Cadastre novos títulos, atualize dados ou faça o upload das capas dos livros.</p>

    <?php if (isset($mensagens[$msg])): ?>
        <p class="aviso" role="status">
            <?= scriptoriaEscapar($mensagens[$msg]) ?>
        </p>
    <?php endif; ?>

    <!-- formulario de cadastro e edicao de livros -->
    <section class="painel">
        <h2><?= $editando ? 'Editar livro' : 'Cadastrar novo livro' ?></h2>

        <form class="formulario" method="POST" action="index.php?pagina=livros" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= scriptoriaEscapar($csrfToken ?? '') ?>">
            <input type="hidden" name="acao" value="salvar">
            <input type="hidden" name="idLivro" value="<?= scriptoriaEscapar($livroEd['idLivro'] ?? '') ?>">

            <div class="campo">
                <label for="titulo">Título *</label>
                <input id="titulo" name="titulo" maxlength="200" required
                       value="<?= scriptoriaEscapar($livroEd['titulo'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="autor">Autor *</label>
                <input id="autor" name="autor" maxlength="150" required
                       value="<?= scriptoriaEscapar($livroEd['autor'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="categoria">Categoria *</label>
                <select id="categoria" name="categoria" required>
                    <option value="">Selecione...</option>
                    <?php foreach ($categoriasOpcoes as $cat): ?>
                        <option value="<?= scriptoriaEscapar($cat) ?>"
                            <?= ($livroEd['categoria'] ?? '') === $cat ? 'selected' : '' ?>>
                            <?= scriptoriaEscapar($cat) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="campo">
                <label for="localizacao">Localização na biblioteca *</label>
                <input id="localizacao" name="localizacao" maxlength="100" required
                       placeholder="Ex: Estante A, Prateleira 2"
                       value="<?= scriptoriaEscapar($livroEd['localizacao'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="anoPublicacao">Ano de publicação</label>
                <input id="anoPublicacao" name="anoPublicacao" type="number" min="1" max="<?= date('Y') ?>"
                       value="<?= scriptoriaEscapar($livroEd['anoPublicacao'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="status">Status *</label>
                <select id="status" name="status" required>
                    <option value="DISPONIVEL" <?= ($livroEd['status'] ?? 'DISPONIVEL') === 'DISPONIVEL' ? 'selected' : '' ?>>Disponível</option>
                    <option value="INDISPONIVEL" <?= ($livroEd['status'] ?? '') === 'INDISPONIVEL' ? 'selected' : '' ?>>Indisponível</option>
                </select>
            </div>

            <div class="campo full">
                <label for="imagem_arquivo">Capa do Livro (Upload de Imagem)</label>
                <input id="imagem_arquivo" name="imagem_arquivo" type="file" accept="image/png, image/jpeg, image/webp">
                <input type="hidden" name="imagem" value="<?= scriptoriaEscapar($livroEd['imagem'] ?? '') ?>">
                <?php if (!empty($livroEd['imagem'])): ?>
                    <small>Capa atual cadastrada: <code><?= scriptoriaEscapar($livroEd['imagem']) ?></code></small>
                <?php endif; ?>
            </div>

            <div class="campo full">
                <label for="sinopse">Sinopse</label>
                <textarea id="sinopse" name="sinopse" rows="3"><?= scriptoriaEscapar($livroEd['sinopse'] ?? '') ?></textarea>
            </div>

            <div class="botoes">
                <button class="botao" type="submit">
                    <?= $editando ? 'Salvar alterações' : 'Cadastrar livro' ?>
                </button>

                <?php if ($editando): ?>
                    <a class="botao secundario" href="index.php?pagina=livros">Cancelar edição</a>
                <?php endif; ?>

                <a class="botao secundario" href="index.php?pagina=admin">Voltar ao painel</a>
            </div>
        </form>
    </section>

    <!-- tabela de listagem do acervo -->
    <section class="painel">
        <h2>Livros no acervo (<?= count($listaLivros) ?>)</h2>

        <?php if (empty($listaLivros)): ?>
            <p>Nenhum livro cadastrado no acervo.</p>
        <?php else: ?>
            <div class="tabela-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Título / Autor</th>
                            <th>Categoria</th>
                            <th>Localização</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($listaLivros as $l): ?>
                        <tr>
                            <td>
                                <strong><?= scriptoriaEscapar($l['titulo']) ?></strong><br>
                                <small><?= scriptoriaEscapar($l['autor']) ?></small>
                            </td>
                            <td><?= scriptoriaEscapar($l['categoria']) ?></td>
                            <td><?= scriptoriaEscapar($l['localizacao']) ?></td>
                            <td><?= scriptoriaEscapar($l['status']) ?></td>
                            <td>
                                <div class="acoes">
                                    <a class="botao" href="index.php?pagina=livros&acao=editar&id=<?= (int) $l['idLivro'] ?>">
                                        Editar
                                    </a>

                                    <form method="POST" action="index.php?pagina=livros" onsubmit="return confirm('Deseja excluir este livro?');">
                                        <input type="hidden" name="csrf_token" value="<?= scriptoriaEscapar($csrfToken ?? '') ?>">
                                        <input type="hidden" name="acao" value="excluir">
                                        <input type="hidden" name="idLivro" value="<?= (int) $l['idLivro'] ?>">
                                        <button class="botao perigo" type="submit">Excluir</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</main>