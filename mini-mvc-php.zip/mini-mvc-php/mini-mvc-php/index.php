<?php
//inicia a sessao do usuario
session_start();

//puxa a conexao com o banco
require_once __DIR__ . '/config/database.php';

//pega a pagina da url ou manda pro catalogo por padrao
$pagina = $_GET['pagina'] ?? 'catalogo';

// bloqueia rotas restritas se nao tiver logado como adm
if (in_array($pagina, ['admin', 'livros', 'emprestimos', 'novo_emprestimo', 'devolver_emprestimo', 'usuarios'], true)) {
    if (empty($_SESSION['scriptoria_admin'])) {
        header('Location: index.php?pagina=login');
        exit;
    }
}

// tela de login
if ($pagina === 'login') {
    require __DIR__ . '/views/login_view.php';
    exit;
}

//mata a sessão e desloga o usuário
if ($pagina === 'logout') {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    header('Location: index.php?pagina=login&msg=saiu');
    exit;
}

// abre o painel geral do adm
if ($pagina === 'admin') {
    require_once __DIR__ . '/controllers/AdminController.php';

    $controller = new AdminController($pdo);
    $controller->index();
    exit;
}

//abre a gestao de leitores
if ($pagina === 'usuarios') {
    require_once __DIR__ . '/controllers/UsuarioController.php';

    $controller = new UsuarioController($pdo);
    $controller->gerir();
    exit;
}

//cuida do fluxo de emprestimo e devolucao
if (in_array($pagina, ['emprestimos', 'novo_emprestimo', 'devolver_emprestimo'], true)) {
    require_once __DIR__ . '/controllers/EmprestimoController.php';

    $controller = new EmprestimoController($pdo);

    if ($pagina === 'novo_emprestimo') {
        $controller->salvar();
    } elseif ($pagina === 'devolver_emprestimo') {
        $controller->devolver();
    } else {
        $controller->gerir();
    }
    exit;
}

//manda qualquer outra rota de livro pro controller padrão
require_once __DIR__ . '/controllers/LivroController.php';

$controller = new LivroController($pdo);
$controller->tratarRequisicao();