<?php

require_once __DIR__ . '/../models/LivroModel.php';
require_once __DIR__ . '/../models/UsuarioModel.php';
require_once __DIR__ . '/../models/EmprestimoModel.php';

class AdminController
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    //carrega as contagens e exibe a dashboard adm
    public function index(): void
    {
        $livroModel = new LivroModel($this->pdo);
        $usuarioModel = new UsuarioModel($this->pdo);
        $emprestimoModel = new EmprestimoModel($this->pdo);

        //conta total de livros e os disponiveis
        $todosLivros = method_exists($livroModel, 'listar') ? $livroModel->listar() : [];
        $totalLivros = count($todosLivros);
        
        $totalDisponiveis = 0;
        foreach ($todosLivros as $l) {
            if (($l['status'] ?? 'DISPONIVEL') === 'DISPONIVEL') {
                $totalDisponiveis++;
            }
        }

        //conta leitores e empréstimos ativos
        $totalUsuarios = method_exists($usuarioModel, 'listar') ? count($usuarioModel->listar()) : 0;
        
        if (method_exists($emprestimoModel, 'listarAtivos')) {
            $totalEmprestimos = count($emprestimoModel->listarAtivos());
        } elseif (method_exists($emprestimoModel, 'listar')) {
            $totalEmprestimos = count($emprestimoModel->listar());
        } else {
            $totalEmprestimos = 0;
        }

        //carrega a view do painel
        include __DIR__ . '/../views/layouts/header.php';
        include __DIR__ . '/../views/admin_view.php';
        include __DIR__ . '/../views/layouts/footer.php';
    }
}