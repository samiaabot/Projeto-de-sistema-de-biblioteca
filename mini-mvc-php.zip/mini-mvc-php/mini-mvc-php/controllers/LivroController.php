<?php

require_once __DIR__ . '/../models/LivroModel.php';

class LivroController
{
    private LivroModel $model;

    private array $categorias = [
        'Acadêmicos',
        'Clássicos brasileiros',
        'Ficção',
        'Não ficção',
        'Infantil'
    ];

    //inicia o model de livros
    public function __construct(PDO $pdo)
    {
        $this->model = new LivroModel($pdo);
    }

    //trata as requisicoes do catalogo e populares
    public function tratarRequisicao(): void
    {
        $pagina = $_GET['pagina'] ?? 'catalogo';

        if ($pagina === 'livros') {
            $this->gerirLivros();
            return;
        }

        if ($pagina === 'populares') {
            $livros = $this->model->listarPopulares(12);
            $tituloPagina = 'Mais Populares';
            require __DIR__ . '/../views/layouts/header.php';
            require __DIR__ . '/../views/livros_view.php';
            require __DIR__ . '/../views/layouts/footer.php';
            return;
        }

        $busca = trim((string) ($_GET['busca'] ?? $_GET['pesquisa'] ?? $_GET['termo'] ?? ''));
        $categoria = trim((string) ($_GET['categoria'] ?? ''));

        $livros = $this->model->listar($busca, $categoria);

        require __DIR__ . '/../views/layouts/header.php';
        require __DIR__ . '/../views/livros_view.php';
        require __DIR__ . '/../views/layouts/footer.php';
    }

    //gerencia cadastro edicao e exclusao de livros
    private function gerirLivros(): void
    {
        if (empty($_SESSION['scriptoria_admin'])) {
            header('Location: index.php?pagina=login');
            exit;
        }

        if (empty($_SESSION['scriptoria_csrf'])) {
            $_SESSION['scriptoria_csrf'] = bin2hex(random_bytes(32));
        }

        $csrfToken = $_SESSION['scriptoria_csrf'];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = (string) ($_POST['csrf_token'] ?? '');

            if (!hash_equals($csrfToken, $token)) {
                http_response_code(403);
                exit('Formulário inválido. Atualize a página e tente novamente.');
            }

            $acao = (string) ($_POST['acao'] ?? '');

            //exclui o livro selecionado
            if ($acao === 'excluir') {
                $id = filter_var(
                    $_POST['idLivro'] ?? null,
                    FILTER_VALIDATE_INT
                );

                if (!$id || $id < 1) {
                    $this->redirecionar('erro');
                }

                try {
                    $excluido = $this->model->excluir($id);
                    $this->redirecionar($excluido ? 'excluido' : 'bloqueado');
                } catch (Throwable $e) {
                    error_log($e->getMessage());
                    $this->redirecionar('erro');
                }
            }

            //salva ou atualiza os dados do livro
            if ($acao === 'salvar') {
                $idTexto = trim((string) ($_POST['idLivro'] ?? ''));
                $titulo = trim((string) ($_POST['titulo'] ?? ''));
                $autor = trim((string) ($_POST['autor'] ?? ''));
                $categoria = trim((string) ($_POST['categoria'] ?? ''));
                $status = strtoupper(trim((string) ($_POST['status'] ?? 'DISPONIVEL')));
                $localizacao = trim((string) ($_POST['localizacao'] ?? ''));
                $anoTexto = trim((string) ($_POST['anoPublicacao'] ?? ''));
                $sinopse = trim((string) ($_POST['sinopse'] ?? ''));
                $imagem = trim((string) ($_POST['imagem'] ?? ''));

                //upload da capa do livro
                if (isset($_FILES['imagem_arquivo']) && $_FILES['imagem_arquivo']['error'] === UPLOAD_ERR_OK) {
                    $arquivoTmp = $_FILES['imagem_arquivo']['tmp_name'];
                    $nomeOriginal = $_FILES['imagem_arquivo']['name'];
                    $extensao = strtolower(pathinfo($nomeOriginal, PATHINFO_EXTENSION));

                    $extensoesPermitidas = ['jpg', 'jpeg', 'png', 'webp'];

                    if (in_array($extensao, $extensoesPermitidas, true)) {
                        $pastaDestino = __DIR__ . '/../assets/img/livros/';
                        if (!is_dir($pastaDestino)) {
                            mkdir($pastaDestino, 0777, true);
                        }

                        $novoNome = 'capa_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $extensao;
                        $caminhoFinal = $pastaDestino . $novoNome;

                        if (move_uploaded_file($arquivoTmp, $caminhoFinal)) {
                            $imagem = 'assets/img/livros/' . $novoNome;
                        }
                    }
                }

                if (
                    $titulo === '' ||
                    $autor === '' ||
                    $localizacao === '' ||
                    !in_array($categoria, $this->categorias, true) ||
                    !in_array($status, ['DISPONIVEL', 'INDISPONIVEL'], true)
                ) {
                    $this->redirecionar('erro');
                }

                $ano = null;

                if ($anoTexto !== '') {
                    $anoValidado = filter_var(
                        $anoTexto,
                        FILTER_VALIDATE_INT
                    );

                    if (
                        $anoValidado === false ||
                        $anoValidado < 1 ||
                        $anoValidado > (int) date('Y')
                    ) {
                        $this->redirecionar('erro');
                    }

                    $ano = $anoValidado;
                }

                if (
                    $imagem !== '' &&
                    (
                        strpos($imagem, 'assets/img/livros/') !== 0 ||
                        strpos($imagem, '..') !== false
                    )
                ) {
                    $this->redirecionar('erro');
                }

                try {
                    if ($idTexto !== '') {
                        $id = filter_var($idTexto, FILTER_VALIDATE_INT);

                        if (!$id || $id < 1 || !$this->model->buscarPorId($id)) {
                            $this->redirecionar('erro');
                        }

                        $this->model->atualizar(
                            $id,
                            $titulo,
                            $autor,
                            $categoria,
                            $status,
                            $localizacao,
                            $ano,
                            $sinopse,
                            $imagem
                        );
                    } else {
                        $this->model->inserir(
                            $titulo,
                            $autor,
                            $categoria,
                            $status,
                            $localizacao,
                            $ano,
                            $sinopse,
                            $imagem
                        );
                    }

                    $this->redirecionar('salvo');
                } catch (Throwable $e) {
                    error_log('Erro ao salvar livro: ' . $e->getMessage());
                    $this->redirecionar('erro');
                }
            }

            $this->redirecionar('erro');
        }

        //carrega livro pra edicao
        $livroEdicao = null;

        if (($_GET['acao'] ?? '') === 'editar') {
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

            if ($id && $id > 0) {
                $livroEdicao = $this->model->buscarPorId($id) ?: null;
            }
        }

        $livros = $this->model->listar();

        require __DIR__ . '/../views/layouts/header.php';
        require __DIR__ . '/../views/gerir_livros_view.php';
        require __DIR__ . '/../views/layouts/footer.php';
    }

    //manda de volta com mensagem
    private function redirecionar(string $mensagem): void
    {
        header('Location: index.php?pagina=livros&msg=' . rawurlencode($mensagem));
        exit;
    }

    public function buscarAjax() {
    $termo = filter_input(INPUT_GET, 'q', FILTER_SANITIZE_SPECIAL_CHARS);
    
    if (!empty($termo)) {
        $livroModel = new LivroModel();
        $resultados = $livroModel->buscarPorTermo($termo);
        
        header('Content-Type: application/json');
        echo json_encode($resultados);
        exit;
    }
    
    header('Content-Type: application/json');
    echo json_encode([]);
    exit;
}

}
