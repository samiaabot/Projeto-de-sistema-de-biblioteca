<?php

require_once __DIR__ . '/../models/UsuarioModel.php';

class UsuarioController
{
    private UsuarioModel $model;

    //inicia o model do usuario
    public function __construct(PDO $pdo)
    {
        $this->model = new UsuarioModel($pdo);
    }

    //gerencia todo o fluxo de leitores
    public function gerir(): void
    {
        //valida sessao de adm
        if (empty($_SESSION['scriptoria_admin'])) {
            header('Location: index.php?pagina=login');
            exit;
        }

        //gera o token csrf
        if (empty($_SESSION['scriptoria_csrf'])) {
            $_SESSION['scriptoria_csrf'] = bin2hex(random_bytes(32));
        }

        $csrfToken = $_SESSION['scriptoria_csrf'];

        //processa os envios de formulario
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $token = (string) ($_POST['csrf_token'] ?? '');

            if (!hash_equals($csrfToken, $token)) {
                http_response_code(403);
                exit('Formulário inválido. Atualize a página e tente novamente.');
            }

            $acao = (string) ($_POST['acao'] ?? '');

            //exclui o leitor
            if ($acao === 'excluir') {
                $id = filter_var($_POST['idUsuario'] ?? null, FILTER_VALIDATE_INT);

                if (!$id || $id < 1) {
                    $this->redirecionar('erro');
                }

                try {
                    $excluido = $this->model->excluir($id);
                    $this->redirecionar($excluido ? 'excluido' : 'bloqueado');
                } catch (Throwable $e) {
                    error_log($e->getMessage());
                    $this->redirecionar('erro');
                }
            }

            //salva ou atualiza o leitor
            if ($acao === 'salvar') {
                $idTexto  = trim((string) ($_POST['idUsuario'] ?? ''));
                $nome     = trim((string) ($_POST['nome'] ?? ''));
                $email    = trim((string) ($_POST['email'] ?? ''));
                $telefone = trim((string) ($_POST['telefone'] ?? ''));

                if ($nome === '' || $email === '' || $telefone === '') {
                    $this->redirecionar('erro');
                }

                try {
                    if ($idTexto !== '') {
                        $id = filter_var($idTexto, FILTER_VALIDATE_INT);
                        if (!$id || $id < 1 || !$this->model->buscarPorId($id)) {
                            $this->redirecionar('erro');
                        }
                        $this->model->atualizar($id, $nome, $email, $telefone);
                    } else {
                        $this->model->inserir($nome, $email, $telefone);
                    }

                    $this->redirecionar('salvo');
                } catch (Throwable $e) {
                    error_log('Erro ao salvar utilizador: ' . $e->getMessage());
                    $this->redirecionar('erro');
                }
            }

            $this->redirecionar('erro');
        }

        //carrega leitor pra edicao se solicitado
        $usuarioEdicao = null;
        if (($_GET['acao'] ?? '') === 'editar') {
            $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
            if ($id && $id > 0) {
                $usuarioEdicao = $this->model->buscarPorId($id) ?: null;
            }
        }

        $usuarios = $this->model->listar();

        //renderiza as views
        require __DIR__ . '/../views/layouts/header.php';
        require __DIR__ . '/../views/usuarios_view.php';
        require __DIR__ . '/../views/layouts/footer.php';
    }

    //manda de volta com mensagem na url
    private function redirecionar(string $msg): void
    {
        header('Location: index.php?pagina=usuarios&msg=' . rawurlencode($msg));
        exit;
    }
}