<?php

require_once __DIR__ . '/../models/EmprestimoModel.php';
require_once __DIR__ . '/../models/LivroModel.php';
require_once __DIR__ . '/../models/UsuarioModel.php';

class EmprestimoController
{
    private PDO $pdo;
    private EmprestimoModel $model;

    //inicia o model de emprestimos
    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
        $this->model = new EmprestimoModel($pdo);
    }

    //carrega leitores e livros pra tela principal de emprestimos
    public function gerir(): void
    {
        $usuarioModel = new UsuarioModel($this->pdo);
        $livroModel = new LivroModel($this->pdo);

        $usuariosLista = method_exists($usuarioModel, 'listar') ? $usuarioModel->listar() : [];
        $livrosLista = method_exists($livroModel, 'listar') ? $livroModel->listar() : [];
        $emprestimosAtivos = $this->model->listarAtivos();

        $mensagemSucesso = $_GET['sucesso'] ?? '';
        $mensagemErro = $_GET['erro'] ?? '';

        include __DIR__ . '/../views/layouts/header.php';
        include __DIR__ . '/../views/emprestimos_view.php';
        include __DIR__ . '/../views/layouts/footer.php';
    }

    //salva o novo emprestimo com as datas escolhidas
    public function salvar(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $idUsuario = (int) ($_POST['idUsuario'] ?? 0);
            $idLivro = (int) ($_POST['idLivro'] ?? 0);
            $dataEmprestimo = trim((string) ($_POST['dataEmprestimo'] ?? date('Y-m-d')));
            $dataDevolucao = trim((string) ($_POST['dataDevolucao'] ?? date('Y-m-d', strtotime('+14 days'))));

            if ($idUsuario > 0 && $idLivro > 0) {
                $sucesso = $this->model->criar($idUsuario, $idLivro, $dataEmprestimo, $dataDevolucao);
                if ($sucesso) {
                    header('Location: index.php?pagina=emprestimos&sucesso=Empréstimo+registrado+com+sucesso!');
                    exit;
                }
            }
        }

        header('Location: index.php?pagina=emprestimos&erro=Selecione+um+usuário+e+um+livro+válidos.');
        exit;
    }

    //devolve o livro e atualiza o status
    public function devolver(): void
    {
        $id = (int) ($_GET['id'] ?? 0);
        if ($id > 0) {
            $this->model->devolver($id);
            header('Location: index.php?pagina=emprestimos&sucesso=Devolução+registrada+com+sucesso!');
            exit;
        }

        header('Location: index.php?pagina=emprestimos&erro=ID+inválido.');
        exit;
    }
}